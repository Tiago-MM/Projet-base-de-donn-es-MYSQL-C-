﻿using System;
using MySql.Data.MySqlClient;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace DMMySQL
{
    public class Clients
    {
        int idClients;
        string nom;
        string prenom;
        string numero;
        string mail;
        string mdp;
        string adresse_facturation;
        string cb;
        string fidelite;

        public Clients(int idClients, string nom, string prenom, string numero, string mail, string mdp, string adresseFacturation, string cb, string fidelite)
        {
            this.idClients = idClients;
            this.nom = nom;
            this.prenom = prenom;
            this.numero = numero;
            this.mail = mail;
            this.mdp = mdp;
            this.adresse_facturation = adresseFacturation;
            this.cb = cb;
            this.fidelite = fidelite;
        }
        public Clients()
        {

        }

        public int IdClients
        {
            get { return this.idClients; }
            set { this.idClients = value; }
        }

        public string Nom
        {
            get { return this.nom; }
            set { this.nom = value; }
        }

        public string Prenom
        {
            get { return this.prenom; }
            set { this.prenom = value; }
        }

        public string Numero
        {
            get { return this.numero; }
            set { this.numero = value; }
        }

        public string Mail
        {
            get { return this.mail; }
            set { this.mail = value; }
        }

        public string Mdp
        {
            get { return this.mdp; }
            set { this.mdp = value; }
        }

        public string AdresseFacturation
        {
            get { return this.adresse_facturation; }
            set { this.adresse_facturation = value; }
        }

        public string Cb
        {
            get { return this.cb; }
            set { this.cb = value; }
        }

        public string Fidelite
        {
            get { return this.fidelite; }
            set { this.fidelite = value; }
        }



        public static void Client(MySqlConnection connection)
        {
            MyImage fleurs = new MyImage("./Clients.bmp");
            fleurs.Afficher();
            string[] tableaurep = { "oui", "non" };
            string reponse = "";
            do
            {
                Console.WriteLine("Êtes vous un nouveau client ? (oui, non)");
                reponse = Console.ReadLine();
            } while (!tableaurep.Contains(reponse));
            int id = 0;
            string prenom = "";
            string nom = "";
            string numero = "";
            string adresse_facturation = "";
            string mail = "";
            string cb = "";
            string fidel = "";
            string mdp = "";
            Clients clientactuel = new Clients();


            if (reponse == "oui")
            {
                Console.WriteLine("Entrer votre prenom :");
                prenom = Console.ReadLine();

                Console.WriteLine("Entrer votre nom de famille :");
                nom = Console.ReadLine();

                Console.WriteLine("Entrer votre numero de télephone :");
                numero = Console.ReadLine();

                int lid = 0;
                do
                {
                    Console.WriteLine("Entrer votre mail :");
                    mail = Console.ReadLine();
                    connection.Open();
                    MySqlCommand command1 = connection.CreateCommand();
                    command1.CommandText = "select id from clients where courriel=\'"+mail+"\'";
                    lid = Convert.ToInt32(command1.ExecuteScalar());
                    connection.Close();
                } while (lid != 0);
                Console.WriteLine("Entrer votre carte bancaire :");
                cb = Console.ReadLine();

                Console.WriteLine("Entrer votre adresse de facturation :");
                adresse_facturation = Console.ReadLine();

                mdp = Mdp1();

                fidel = "AUCUN";


                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT MAX(id) FROM Clients";
                int lastId = Convert.ToInt32(command.ExecuteScalar());
                id = lastId + 1;


                // Création d'une nouvelle commande
                // Définition de la requête paramétrée
                command.CommandText = "INSERT INTO Clients (id,nom, prenom, telephone, courriel, mot_de_passe, adresse_facturation, carte_credit, statut_fidélité) VALUES(@id, @nom, @prenom, @telephone, @courriel, @mdp, @adresse_facturation, @cb, @fidel)";

                // Définition des paramètres de la commande
                command.Parameters.AddWithValue("@id", lastId + 1);
                command.Parameters.AddWithValue("@nom", nom);
                command.Parameters.AddWithValue("@prenom", prenom);
                command.Parameters.AddWithValue("@telephone", numero);
                command.Parameters.AddWithValue("@courriel", mail);
                command.Parameters.AddWithValue("@mdp", mdp);
                command.Parameters.AddWithValue("@adresse_facturation", adresse_facturation);
                command.Parameters.AddWithValue("@cb", cb);
                command.Parameters.AddWithValue("@fidel", fidel);

                // Exécution de la commande
                command.ExecuteNonQuery();
                connection.Close();
                clientactuel = new Clients(lastId + 1, nom, prenom, numero, mail, mdp, adresse_facturation, cb, fidel); ;
            }
            else
            {
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                List<string> lesmails = new List<string>();
                do
                {
                    connection.Close();
                    connection.Open();
                    Console.WriteLine("Entrer votre adresse mail :");
                    mail = Console.ReadLine();
                    mdp = Mdp1();
                    command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM Clients WHERE courriel = \'" + mail + "\' AND mot_de_passe = \'" + mdp + "\';";
                    MySqlDataReader reader;
                    reader = command.ExecuteReader();
                    while (reader.Read())                           // parcours ligne par ligne
                    {
                        lesmails.Add(reader.GetString(0));
                    }
                } while (lesmails.Count() != 1);
                connection.Close();
                connection.Open();
                command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM Clients WHERE courriel = \'" + mail + "\' AND mot_de_passe = \'" + mdp + "\';";
                MySqlDataReader reader1;
                reader1 = command.ExecuteReader();
                while (reader1.Read())                           // parcours ligne par ligne
                {
                    clientactuel = new Clients(
                    idClients: reader1.GetInt32(0),
                    nom: reader1.GetString(1),
                    prenom: reader1.GetString(2),
                    numero: reader1.GetString(3),
                    mail: reader1.GetString(4),
                    mdp: reader1.GetString(5),
                    adresseFacturation: reader1.GetString(6),
                    cb: reader1.GetString(7),
                    fidelite: reader1.GetString(8));
                }
                connection.Close();
            }
            Fideliteduclient(connection,clientactuel);
            string[] tableaudereponse = { "1", "2", "3", "4" };
            Console.WriteLine("Que souhaitez vous faire ?");
            Console.WriteLine("1 Consulter mes commandes passées" +
                "\n\n 2 Acheter un produit" +
                "\n\n 3 Consulter/modifier mes informations personnelles" +
                "\n\n 4 Supprimer mon compte");
            string reponse1 = Console.ReadLine();
            switch (reponse1)
            {
                case "1":
                    Commandespassees(connection, clientactuel);
                    break;
                case "2":
                    Acheter(connection, clientactuel);

                    break;
                case "3":
                    Modifierinfo(connection, clientactuel);

                    break;
                case "4":
                    Supprimer(connection, clientactuel);
                    break;
            }
            //connection.Close();


        }

        static void Fideliteduclient(MySqlConnection connection, Clients clientactuel)
        {
            string dateAujourdhui = DateTime.Today.ToString("MM");
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select count(*)  as nbcommande,cl.nom from Commandes c join Clients cl on " +
                "c.id_client=cl.id where MONTH(c.date_creation)="+dateAujourdhui+" and cl.id="+clientactuel.IdClients+";";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            //int i = 0;
            string staut = "";
            int nombrecommande = 0;
            while (reader.Read())                           // parcours ligne par ligne
            {
                nombrecommande = reader.GetInt32(0);
            }
            connection.Close();
            if (nombrecommande >= 1)
            {
                if (nombrecommande >= 5)
                    staut = "OR";
                else
                    staut = "BRONZE";
            }
            else
                staut = "AUCUN";
            clientactuel.fidelite = staut;
            connection.Open();
            MySqlCommand command1 = connection.CreateCommand();
            command1.CommandText = "update clients set statut_fidélité= \'"+ staut+"\' where clients.id= "+clientactuel.idClients+" ;";
            command1.ExecuteNonQuery();
            connection.Close();
            Console.WriteLine("Fidélité actuel :"+staut);
            Console.WriteLine('\n');
        }





        ////////Requetes client////////////////////////////////////////////////////////////////////////////////////////////
        ////////Requetes client////////////////////////////////////////////////////////////////////////////////////////////


        //Supprimer son compte
        static void Supprimer(MySqlConnection connection, Clients clientactuel)
        {
            Console.Clear();
            string reponse = "";
            Console.WriteLine("Êtes vous sur de supprimer votre compte ?");
            reponse = Console.ReadLine();
            if (reponse=="oui")
            {
                connection.Open();
                MySqlCommand command1 = connection.CreateCommand();
                command1.CommandText = "delete clients from clients where clients.id=" + clientactuel.idClients + ";";
                command1.ExecuteNonQuery();
                connection.Close();
                Console.WriteLine("Votre compte a bien été supprimé");
            }
        }


        //Méthode afin de connaître les commandes passées par un client
        static void Commandespassees(MySqlConnection connection, Clients clientactuel)
        {
            Console.Clear();
            List<string> laliste = new List<string>();
            connection.Close();
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY sc.date_etat DESC LIMIT 1),(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE sc.id_commande = c.id) FROM Commandes c WHERE c.id_client = " + clientactuel.IdClients + ";";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            int abc = 0;
            Console.WriteLine();
            while (reader.Read())                           // parcours ligne par ligne
            {
                if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.White;
                abc += 1;
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                //i += 1;
                Console.WriteLine(reader.GetInt32(0) + " " + reader.GetString(1) + " " + reader.GetDateTime(2));//modifier la date dans mysql
                laliste.Add(Convert.ToString(reader.GetInt32(0)));
            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Souhaitez vous obtenir plus d'informations sur une de vos commandes ? (1,2...; ou non)");
            string reponse = "";
            reponse = Console.ReadLine();
            if (laliste.Contains(reponse)) //tableau contient reponse     
            {
                connection.Close();
                connection.Open();
                command = connection.CreateCommand();
                command.CommandText = "SELECT DISTINCT cl.prenom, cl.nom, c.id, sc.code_etat as statut, sc.date_etat as date, c.date_creation, c.date_livraison " +
                    "FROM Commandes c, Clients cl, Statuts_Commandes sc, Produits p, Commandes_Produits cp " +
                    "WHERE c.id = cp.id_commande AND cp.id_produit = p.id AND c.id_client = cl.id AND c.id = sc.id_commande AND c.id = "+reponse+" order by date";
                reader = command.ExecuteReader();
                Console.WriteLine();
                Console.WriteLine("Prenom    Nom     N° commande  Statut       Date de maj      Produits commandés     Date de commande       Date de livraison");
                while (reader.Read())                           // parcours ligne par ligne
                {
                    laliste.Add(Convert.ToString(reader.GetInt32(2)));

                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    Console.WriteLine(string.Join(" | ", values));
                    Console.WriteLine();
                }
                connection.Close();
                connection.Open();
                command = connection.CreateCommand();
                command.CommandText = "select GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as produits FROM Commandes c, magasins m, " +
                    "Produits p, Commandes_Produits cp,clients cl where c.id_magasin = m.id and cp.id_produit = p.id and cp.id_commande = c.id and " +
                    "c.id_client = cl.id and c.id = " + reponse;
                reader = command.ExecuteReader();
                Console.WriteLine();
                Console.WriteLine("Prenom    Nom     N° commande  Statut actuel       Date de maj      Produits commandés     Date de commande       Date de livraison");
                while (reader.Read())                           // parcours ligne par ligne
                {
                    Console.WriteLine(reader.GetString(0) + " (Produits commandés)");
                }
                connection.Close();

            }
            else
            {
            }
            connection.Close();
        }

        //Méthode d'achat
        static void Acheter(MySqlConnection connection, Clients clientactuel)
        {
            Console.Clear();
            string[] tabrep = { "1", "2" };
            string reponse = "";
            do
            {
                Console.WriteLine("Que souhaitez vous acheter ?");
                Console.WriteLine();
                Console.WriteLine("1 Des bouquets de fleurs" +
                    "\n2 Un arrangement florale");
                reponse = Console.ReadLine();
            } while (!tabrep.Contains(reponse));

            switch (reponse)
            {
                case "1":
                    Acheterbouquet(connection, clientactuel);
                    break;
                case "2":
                    string reponse7 = "";
                    string[] tabrep1 = { "oui", "non" };
                    do
                    {
                        Console.WriteLine("Savez vous de façon précise ce que vous allez acheter ? (oui , non)");
                        reponse7 = Console.ReadLine();

                    } while (!tabrep1.Contains(reponse7));
                    if (reponse7 == "oui")
                    {
                        Acheterarrangementprecis(connection, clientactuel);
                    }
                    else
                    {
                        Acheterarrangementnonprecis(connection, clientactuel);
                    }

                    break;
            }
        }
        static void Acheterarrangementprecis(MySqlConnection connection, Clients clientactuel)
        {
            Console.Clear();
            List<string> listedesproduits = new List<string>();
            List<string> produits = new List<string>();
            List<string> quantites = new List<string>();//Liste pour les lignes de commandes
            string[] tabrep1 = { "1", "2", "3" };
            string idmagasin = "";
            string reponse = "";
            string reponse2 = "";
            string continuer = "oui";
            string notin = "-2,";
            int stock = -1;
            do
            {
                Console.WriteLine("Où souhaitez vous commander ?");
                Console.WriteLine("1 Les douces fleurs de Sarah" +
                    "\n2 Les belles fleurs de Marie");
                idmagasin = Console.ReadLine();
            } while (!tabrep1.Contains(idmagasin));


            do
            {
                do
                {
                    do
                    {
                        connection.Open();
                        MySqlCommand command = connection.CreateCommand();
                        command.CommandText = "select p.id, p.nom, prix, quantite from produits p,magasins m,Inventaire_Magasin im where m.id=" + idmagasin + " and im.id_magasin = m.id and im.id_produit = p.id and p.categorie IN ('FLEUR','ACCESSOIRE') AND p.id NOT IN (" + notin + "-1);";
                        MySqlDataReader reader;
                        reader = command.ExecuteReader();
                        Console.WriteLine("   Produit    prix     quantité restant");
                        while (reader.Read())                           // parcours ligne par ligne
                        {
                            Console.WriteLine(reader.GetString(0) + " " + reader.GetString(1) + " " + reader.GetString(2) + " " + reader.GetString(3));
                            listedesproduits.Add(reader.GetString(0));
                        }
                        connection.Close();
                        Console.WriteLine("Que souhaitez vous commander ?");
                        reponse = Console.ReadLine();
                    } while (!listedesproduits.Contains(reponse));

                    connection.Open();
                    MySqlCommand command1 = connection.CreateCommand();
                    command1.CommandText = "select quantite from produits p,magasins m,Inventaire_Magasin im where m.id=" + idmagasin + " and im.id_produit=" + reponse + " and im.id_magasin = m.id and im.id_produit = p.id and p.categorie IN ('FLEUR','ACCESSOIRE');";
                    MySqlDataReader reader1;
                    reader1 = command1.ExecuteReader();
                    while (reader1.Read())                           // parcours ligne par ligne
                    {
                        stock = reader1.GetInt32(0);
                    }
                    connection.Close();

                    Console.WriteLine("Combien souhaitez vous en avoir ?");
                    reponse2 = Console.ReadLine();

                } while (Convert.ToInt32(reponse2) > stock);

                produits.Add(reponse);
                notin += reponse + ",";
                quantites.Add(reponse2);

                Console.WriteLine("Souhaitez vous aujouter autre choses ? (oui , non)");
                continuer = Console.ReadLine();

            } while (continuer == "oui");


            Console.WriteLine("Entrer votre adresse de livraison");
            string reponse4 = "";
            reponse4 = Console.ReadLine();
            Console.WriteLine("Entrer le message de votre bouquet :");
            string reponse5 = "";
            reponse5 = Console.ReadLine();

            string dateAujourdhui = DateTime.Today.ToString("yyyy/MM/dd");

            Console.WriteLine("Entrer la date de livraison que vous souhaitez avoir : (AAAA/MM/DD)");
            string reponse6 = "";
            reponse6 = Console.ReadLine();




            connection.Open();
            MySqlCommand command2 = connection.CreateCommand();
            command2.CommandText = "SELECT MAX(id) FROM Commandes";
            int idcommande = Convert.ToInt32(command2.ExecuteScalar());


            // Création d'une nouvelle commande
            // Définition de la requête paramétrée
            command2.CommandText = "INSERT INTO Commandes (id, id_client, id_magasin, date_creation, adresse_livraison, message_accompagnant, date_livraison) VALUES(@id, @id_client, @id_magasin, @date_creation, @adresse_livraison, @message_accompagnant, @date_livraison);";

            // Définition des paramètres de la commande
            command2.Parameters.AddWithValue("@id", idcommande + 1);
            command2.Parameters.AddWithValue("@id_client", clientactuel.IdClients);
            command2.Parameters.AddWithValue("@id_magasin", Convert.ToInt32(idmagasin));
            command2.Parameters.AddWithValue("@date_creation", dateAujourdhui);
            command2.Parameters.AddWithValue("@adresse_livraison", reponse4);
            command2.Parameters.AddWithValue("@message_accompagnant", reponse5);
            command2.Parameters.AddWithValue("@date_livraison", reponse6);

            // Exécution de la commande
            command2.ExecuteNonQuery();
            connection.Close();


            //Ajout des lignes de commandes
            for (int i = 0; i < produits.Count(); i++)
            {
                connection.Open();
                command2 = connection.CreateCommand();
                command2.CommandText = "SELECT MAX(id) FROM Commandes_Produits";
                int idligne = Convert.ToInt32(command2.ExecuteScalar());


                command2.CommandText = "INSERT INTO Commandes_Produits (id, id_commande, id_produit, quantite) VALUES(@id, @id_commande, @id_produit, @quantite);";

                // Définition des paramètres de la commande
                command2.Parameters.AddWithValue("@id", idligne + 1);
                command2.Parameters.AddWithValue("@id_commande", idcommande + 1);
                command2.Parameters.AddWithValue("@id_produit", Convert.ToInt32(produits[i]));
                command2.Parameters.AddWithValue("@quantite", Convert.ToInt32(quantites[i]));

                // Exécution de la commande
                command2.ExecuteNonQuery();
                connection.Close();
            }

            string code_etat = "CC";
            //Cas où la commande est effectuée au moins 3 jours avant



            connection.Open();
            command2 = connection.CreateCommand();
            command2.CommandText = "SELECT MAX(id) FROM Statuts_Commandes";
            int idstatut = Convert.ToInt32(command2.ExecuteScalar());


            // Définition de la requête paramétrée
            command2.CommandText = "INSERT INTO Statuts_Commandes (id, id_commande, code_etat, date_etat) VALUES (@id, @id_commande, @code_etat, @date_etat);";

            // Définition des paramètres de la commande
            command2.Parameters.AddWithValue("@id", idstatut + 1);
            command2.Parameters.AddWithValue("@id_commande", idcommande + 1);
            command2.Parameters.AddWithValue("@code_etat", code_etat);
            command2.Parameters.AddWithValue("@date_etat", dateAujourdhui);

            // Exécution de la commande
            command2.ExecuteNonQuery();
            connection.Close();


            for (int i = 0; i < produits.Count(); i++)
            {
                connection.Open();
                MySqlCommand command1 = connection.CreateCommand();
                command1.CommandText = "update Inventaire_Magasin set quantite= quantite-" + quantites[i] + " where id_produit=" + produits[i] + " AND id_magasin=" + idmagasin + ";";
                command1.ExecuteNonQuery();
                connection.Close();
            }
        }






        static void Acheterarrangementnonprecis(MySqlConnection connection, Clients clientactuel)
        {
            Console.Clear();
            List<string> listedesproduits = new List<string>();
            List<string> produits = new List<string>();//Liste pour les lignes de commandes
            string[] tabrep1 = { "1", "2", "3" };
            string idmagasin = "";
            string reponse = "";
            string continuer = "oui";
            string budgetmax = "";
            do
            {
                Console.WriteLine("Où souhaitez vous commander ?");
                Console.WriteLine("1 Les douces fleurs de Sarah" +
                    "\n2 Les belles fleurs de Marie");
                idmagasin = Console.ReadLine();
            } while (!tabrep1.Contains(idmagasin));


            do
            {
                do
                {
                    connection.Open();
                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "select p.id, p.nom, prix, quantite from produits p,magasins m,Inventaire_Magasin im where m.id=" + idmagasin + " and im.id_magasin = m.id and im.id_produit = p.id and p.categorie IN ('FLEUR','ACCESSOIRE');";
                    MySqlDataReader reader;
                    reader = command.ExecuteReader();
                    Console.WriteLine("   Produit    prix");
                    while (reader.Read())                           // parcours ligne par ligne
                    {
                        Console.WriteLine(reader.GetString(0) + " " + reader.GetString(1) + " " + reader.GetString(2));
                        listedesproduits.Add(reader.GetString(0));
                    }
                    connection.Close();
                    Console.WriteLine("Que souhaitez vous commander ?");
                    reponse = Console.ReadLine();
                } while (!listedesproduits.Contains(reponse));

                produits.Add(reponse);

                Console.WriteLine("Souhaitez vous aujouter autre choses ? (oui , non)");
                continuer = Console.ReadLine();

            } while (continuer == "oui");

            Console.WriteLine("Entrer votre budget maximale");
            budgetmax = Console.ReadLine();


            Console.WriteLine("Entrer votre adresse de livraison");
            string reponse4 = "";
            reponse4 = Console.ReadLine();
            Console.WriteLine("Entrer le message de votre bouquet :");
            string reponse5 = "";
            reponse5 = Console.ReadLine();
            reponse5 += "-" + budgetmax;

            string dateAujourdhui = DateTime.Today.ToString("yyyy/MM/dd");

            Console.WriteLine("Entrer la date de livraison que vous souhaitez avoir : (AAAA/MM/DD)");
            string reponse6 = "";
            reponse6 = Console.ReadLine();




            connection.Open();
            MySqlCommand command2 = connection.CreateCommand();
            command2.CommandText = "SELECT MAX(id) FROM Commandes";
            int idcommande = Convert.ToInt32(command2.ExecuteScalar());


            // Création d'une nouvelle commande
            // Définition de la requête paramétrée
            command2.CommandText = "INSERT INTO Commandes (id, id_client, id_magasin, date_creation, adresse_livraison, message_accompagnant, date_livraison) VALUES(@id, @id_client, @id_magasin, @date_creation, @adresse_livraison, @message_accompagnant, @date_livraison);";

            // Définition des paramètres de la commande
            command2.Parameters.AddWithValue("@id", idcommande + 1);
            command2.Parameters.AddWithValue("@id_client", clientactuel.IdClients);
            command2.Parameters.AddWithValue("@id_magasin", Convert.ToInt32(idmagasin));
            command2.Parameters.AddWithValue("@date_creation", dateAujourdhui);
            command2.Parameters.AddWithValue("@adresse_livraison", reponse4);
            command2.Parameters.AddWithValue("@message_accompagnant", reponse5);
            command2.Parameters.AddWithValue("@date_livraison", reponse6);

            // Exécution de la commande
            command2.ExecuteNonQuery();
            connection.Close();


            //Ajout des lignes de commandes
            for (int i = 0; i < produits.Count(); i++)
            {
                connection.Open();
                command2 = connection.CreateCommand();
                command2.CommandText = "SELECT MAX(id) FROM Commandes_Produits";
                int idligne = Convert.ToInt32(command2.ExecuteScalar());


                command2.CommandText = "INSERT INTO Commandes_Produits (id, id_commande, id_produit, quantite) VALUES(@id, @id_commande, @id_produit, @quantite);";

                // Définition des paramètres de la commande
                command2.Parameters.AddWithValue("@id", idligne + 1);
                command2.Parameters.AddWithValue("@id_commande", idcommande + 1);
                command2.Parameters.AddWithValue("@id_produit", Convert.ToInt32(produits[i]));
                command2.Parameters.AddWithValue("@quantite", Convert.ToInt32(0));

                // Exécution de la commande
                command2.ExecuteNonQuery();
                connection.Close();
            }

            string code_etat = "CPAV";
            //Cas où la commande est effectuée au moins 3 jours avant



            connection.Open();
            command2 = connection.CreateCommand();
            command2.CommandText = "SELECT MAX(id) FROM Statuts_Commandes";
            int idstatut = Convert.ToInt32(command2.ExecuteScalar());


            // Définition de la requête paramétrée
            command2.CommandText = "INSERT INTO Statuts_Commandes (id, id_commande, code_etat, date_etat) VALUES (@id, @id_commande, @code_etat, @date_etat);";

            // Définition des paramètres de la commande
            command2.Parameters.AddWithValue("@id", idstatut + 1);
            command2.Parameters.AddWithValue("@id_commande", idcommande + 1);
            command2.Parameters.AddWithValue("@code_etat", code_etat);
            command2.Parameters.AddWithValue("@date_etat", dateAujourdhui);

            // Exécution de la commande
            command2.ExecuteNonQuery();
            connection.Close();
        }





        static void Acheterbouquet(MySqlConnection connection, Clients clientactuel)
        {
            Console.Clear();
            List<int> listdesbouquets = new List<int>();
            string reponse = "99999999";
            do
            {
                connection.Open();
                Console.WriteLine("Quel bouquet souhaitez vous acheter ?");
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "select id,nom, prix from produits p where p.categorie='BOUQUET_STANDARD';";
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                while (reader.Read())                           // parcours ligne par ligne
                {

                    Console.WriteLine(reader.GetInt32(0) + " " + reader.GetString(1) + " " + reader.GetString(2));
                    listdesbouquets.Add(reader.GetInt32(0));
                }
                connection.Close();
                reponse = Console.ReadLine();
            } while (!listdesbouquets.Contains(Convert.ToInt32(reponse)));
            Console.WriteLine("Combien souhaitez vous en avoir ?");
            string reponse2 = "";
            reponse2 = Console.ReadLine();
            //Quel magasin, ruprute de srock ou x restant,
            Console.WriteLine("Quel magasin souhaitez vous chosir ? (si vous choisissez un délai de livraison inférieure à 3 jours, vous serez livré." +
                "\nDans le cas contraire, il y a un risque de pénurie, un employé viendra vers vous)");
            string reponse3 = "";
            connection.Open();
            MySqlCommand commanda = connection.CreateCommand();
            commanda.CommandText = "select id, nom from magasins;";
            MySqlDataReader readera;
            readera = commanda.ExecuteReader();
            while (readera.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.WriteLine(readera.GetInt32(0) + " " + readera.GetString(1));
            }
            connection.Close();
            reponse3 = Console.ReadLine();
            Console.WriteLine("Entrer votre adresse de livraison");
            string reponse4 = "";
            reponse4 = Console.ReadLine();
            Console.WriteLine("Entrer le message de votre bouquet :");
            string reponse5 = "";
            reponse5 = Console.ReadLine();

            string dateAujourdhui = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            Console.WriteLine("Entrer la date de livraison que vous souhaitez avoir : (AAAA/MM/DD)");
            string reponse6 = "";
            reponse6 = Console.ReadLine();




            connection.Open();
            MySqlCommand command1 = connection.CreateCommand();
            command1.CommandText = "SELECT MAX(id) FROM Commandes";
            int idcommande = Convert.ToInt32(command1.ExecuteScalar());


            // Création d'une nouvelle commande
            // Définition de la requête paramétrée
            command1.CommandText = "INSERT INTO Commandes (id, id_client, id_magasin, date_creation, adresse_livraison, message_accompagnant, date_livraison) VALUES(@id, @id_client, @id_magasin, @date_creation, @adresse_livraison, @message_accompagnant, @date_livraison);";

            // Définition des paramètres de la commande
            command1.Parameters.AddWithValue("@id", idcommande + 1);
            command1.Parameters.AddWithValue("@id_client", clientactuel.IdClients);
            command1.Parameters.AddWithValue("@id_magasin", Convert.ToInt32(reponse3));
            command1.Parameters.AddWithValue("@date_creation", dateAujourdhui);
            command1.Parameters.AddWithValue("@adresse_livraison", reponse4);
            command1.Parameters.AddWithValue("@message_accompagnant", reponse5);
            command1.Parameters.AddWithValue("@date_livraison", reponse6);

            // Exécution de la commande
            command1.ExecuteNonQuery();
            connection.Close();


            connection.Open();
            command1 = connection.CreateCommand();
            command1.CommandText = "SELECT MAX(id) FROM Commandes_Produits";
            int idligne = Convert.ToInt32(command1.ExecuteScalar());


            // Création d'une nouvelle commande
            // Définition de la requête paramétrée
            command1.CommandText = "INSERT INTO Commandes_Produits (id, id_commande, id_produit, quantite) VALUES(@id, @id_commande, @id_produit, @quantite);";

            // Définition des paramètres de la commande
            command1.Parameters.AddWithValue("@id", idligne + 1);
            command1.Parameters.AddWithValue("@id_commande", idcommande + 1);
            command1.Parameters.AddWithValue("@id_produit", Convert.ToInt32(reponse));
            command1.Parameters.AddWithValue("@quantite", Convert.ToInt32(reponse2));

            // Exécution de la commande
            command1.ExecuteNonQuery();
            connection.Close();





            DateTime date = DateTime.Parse(reponse6);
            TimeSpan difference = date.Subtract(DateTime.Today);



            string code_etat = "";
            //Cas où la commande est effectuée au moins 3 jours avant
            if (Convert.ToInt32(difference.TotalDays) >= 3)
            {
                int stock = 0;
                code_etat = "CC";
                connection.Open();
                MySqlCommand command3 = connection.CreateCommand();
                command3.CommandText = "select quantite from Inventaire_Magasin where id_produit=" + reponse + " AND id_magasin=" + reponse3 + ";";
                readera = commanda.ExecuteReader();
                while (readera.Read())                           // parcours ligne par ligne
                {
                    //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                    stock = readera.GetInt32(0);
                }
                connection.Close();
                if (stock-Convert.ToInt32(reponse2)<0)
                {
                    connection.Open();
                    command3.CommandText = "update Inventaire_Magasin set quantite= 0 where id_produit=" + reponse + " AND id_magasin=" + reponse3 + ";";
                    command3.ExecuteNonQuery();
                    connection.Close();
                }
                else
                {
                    connection.Open();
                    command3.CommandText = "update Inventaire_Magasin set quantite= quantite-" + reponse2 + " where id_produit=" + reponse + " AND id_magasin=" + reponse3 + ";";
                    command3.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //Cas <3
            else
            {
                code_etat = "VINV";
            }
            connection.Open();
            command1 = connection.CreateCommand();
            command1.CommandText = "SELECT MAX(id) FROM Statuts_Commandes";
            int idstatut = Convert.ToInt32(command1.ExecuteScalar());


            // Définition de la requête paramétrée
            command1.CommandText = "INSERT INTO Statuts_Commandes (id, id_commande, code_etat, date_etat) VALUES (@id, @id_commande, @code_etat, @date_etat);";

            // Définition des paramètres de la commande
            command1.Parameters.AddWithValue("@id", idstatut + 1);
            command1.Parameters.AddWithValue("@id_commande", idcommande + 1);
            command1.Parameters.AddWithValue("@code_etat", code_etat);
            command1.Parameters.AddWithValue("@date_etat", dateAujourdhui);

            // Exécution de la commande
            command1.ExecuteNonQuery();
            connection.Close();

            //Faire l'inventaire qui diminue
        }

        //Permet de modifier les informations personnelles du client
        static void Modifierinfo(MySqlConnection connection, Clients clientactuel)
        {
            Console.Clear();
            connection.Open();
            string reponse = "";
            Console.WriteLine("Vos informations personnelles :");
            Console.WriteLine("1 Nom : " + clientactuel.Nom +
            "\n2 Prenom : " + clientactuel.Prenom +
            "\n3 Numero : " + clientactuel.Numero +
            "\n4 Mail : " + clientactuel.Mail +
            "\n5 Mot de passe : " + clientactuel.Mdp +
            "\n6 Adresse de facturation : " + clientactuel.AdresseFacturation +
            "\n7 Carte bancaire : " + clientactuel.Cb);
            Console.WriteLine("Choisissez une information à modifier");
            reponse = Console.ReadLine();
            string amodifier = "";
            switch (reponse)
            {
                case "1":
                    amodifier = "nom";
                    break;
                case "2":
                    amodifier = "prenom";
                    break;
                case "3":
                    amodifier = "telephone";
                    break;
                case "4":
                    amodifier = "courriel";
                    break;
                case "5":
                    amodifier = "mot_de_passe";
                    break;
                case "6":
                    amodifier = "adresse_facturation";
                    break;
                case "7":
                    amodifier = "carte_credit";
                    break;
            }
            Console.WriteLine("Par quoi souhaitez vous modifier ?");
            string reponsemaj = Console.ReadLine();
            MySqlCommand command1 = connection.CreateCommand();
            command1.CommandText = "update clients set " + amodifier + "= \'" + reponsemaj + "\'where id=" + clientactuel.IdClients + ";";
            command1.ExecuteNonQuery();
            connection.Close();
        }






        static string Mdp1()
        {
            Console.WriteLine("Entrer un mot de passe : ");
            string password = "";

            // Masquage de la saisie de l\'utilisateur
            while (true)
            {
                ConsoleKeyInfo key = Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter)
                    break;
                else if (key.Key == ConsoleKey.Backspace)
                {
                    if (password.Length > 0)
                    {
                        password = password.Substring(0, password.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                else
                {
                    password += key.KeyChar;
                    Console.Write("*");
                }
            }
            Console.WriteLine();
            return password;
        }


    }
}
