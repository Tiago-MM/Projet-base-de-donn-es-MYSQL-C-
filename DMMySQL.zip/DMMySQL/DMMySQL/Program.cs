﻿using System;
using MySql.Data.MySqlClient;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OxyPlot;
using OxyPlot.Series;
using OxyPlot.WindowsForms;


namespace DMMySQL
{
    class MainClass
    {
        static void Main(string[] args)
        {
            MyImage fleurs = new MyImage("./Fleurs.bmp");
            fleurs.Afficher();
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=FLEURS1;UID=root;PASSWORD=Azertyuiop1!;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            string[] tableau = { "employé", "propriétaire", "client" };
            string reponseutilisateur = "";
            do
            {
                Console.WriteLine("Bonjour qui êtes vous ? (employé, propriétaire, client)");
                reponseutilisateur = Console.ReadLine();
            }
            while (!tableau.Contains(reponseutilisateur));
            Console.Clear();
            switch (reponseutilisateur)
            {
                case "employé":
                    Vendeur.Employe(connection);
                    break;
                case "client":
                    Clients.Client(connection);
                    break;
                case "propriétaire":
                    Chef.Propriétaire(connection);
                    break;
            }
            connection.Close();
            //Meilleurmagasin(connection);
            MyImage Merci = new MyImage("./Merci.bmp");
            Merci.Afficher();
            Console.ReadLine();
        }
    }
}
