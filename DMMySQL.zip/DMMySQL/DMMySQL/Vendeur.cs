﻿using System;
using MySql.Data.MySqlClient;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace DMMySQL
{
    public class Vendeur
    {
        public Vendeur()
        {
        }

        public static void Employe(MySqlConnection connection)
        {
            MyImage fleurs = new MyImage("./Employe.bmp");
            fleurs.Afficher();
            string pseudo = "";
            string mdppseudo = "";
            do
            {
                Console.WriteLine("Entrer pseudo");
                pseudo = Console.ReadLine();
                Console.WriteLine("Entrer mot de passe");
                mdppseudo = Console.ReadLine();

            } while (pseudo != mdppseudo || pseudo != "employé");
            string reponse = "";
            string reponse1 = "";
            string idmagasin = "";
            Console.WriteLine("Dans quel boutique travaillez vous ?");
            string[] tableaudereponse = { "1", "2","3","4" };
            Console.WriteLine("Quelles statistiques souhaitez vous connaître ?");
            Console.WriteLine("1 boutique1" +
                "\n2 boutique2");
            reponse = Console.ReadLine();
            switch (reponse)
            {
                case "1":
                    idmagasin = "1";
                    break;
                case "2":
                    idmagasin = "2";
                    break;
            }
            do
            {
                Console.WriteLine("Que souhaitez vous faire ?");
                Console.WriteLine("1 Consulter & modifier les statuts des commandes en cours" +
                    "\n\n2 Vérifier & modifier les commandes CPAV " +
                    "\n\n3 Vérifier & modifier les commandes VINV" +
                    "\n\n4 Ajouter dans l'inventaire");
                reponse1 = Console.ReadLine();

            }
            while (!tableaudereponse.Contains(reponse1));

            switch (reponse1)
            {
                case "1":
                    Statutsmodif(connection, idmagasin);
                    break;

                case "2":
                    CPAV(connection, idmagasin);
                    break;
                case "3":
                    VINV(connection, idmagasin);
                    break;
                case "4":
                    Inventaire(connection, idmagasin);
                    break;
            }


        }

        static void VINV(MySqlConnection connection, string idmagasin)
        {
            Console.Clear();
            string cpav = "";
            string reponse = "";
            do
            {
                List<string> laliste = new List<string>();
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT cl.prenom,cl.nom,c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY " +
                    "sc.date_etat DESC LIMIT 1) as statut,(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE " +
                    "sc.id_commande = c.id) as date, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as produits,c.date_creation, c.date_livraison " +
                    "FROM Commandes c, magasins m, Produits p, Commandes_Produits cp,clients cl where c.id_magasin = m.id and " +
                    "m.id = " + idmagasin + " and cp.id_produit = p.id and cp.id_commande = c.id and c.id_client = cl.id group by c.id order by statut DESC";
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                Console.WriteLine();
                Console.WriteLine("Prenom    Nom     N° commande  Statut actuel       Date de maj      Produits commandés     Date de commande       Date de livraison");
                int abc = 0;
                while (reader.Read())                           // parcours ligne par ligne
                {
                    if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                    else Console.ForegroundColor = ConsoleColor.White;
                    abc += 1;
                    laliste.Add(Convert.ToString(reader.GetInt32(2)));

                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    Console.WriteLine(string.Join(" | ", values));
                    Console.WriteLine();


                }
                Console.ForegroundColor = ConsoleColor.White;
                connection.Close();
                reponse = "";
                Console.WriteLine("Vérifier les commandes VINV ? (Selectionner le n° de commande) (1,2...; ou non)");
                reponse = Console.ReadLine();

                if (laliste.Contains(reponse)) //tableau contient reponse
                {
                    connection.Open();
                    command = connection.CreateCommand();
                    command.CommandText = "SELECT cl.prenom,cl.nom,c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY " +
                        "sc.date_etat DESC LIMIT 1) as statut,(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE " +
                        "sc.id_commande = c.id) as date, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as produits,c.date_creation, c.date_livraison " +
                        "FROM Commandes c, magasins m, Produits p, Commandes_Produits cp,clients cl where c.id_magasin = m.id and " +
                        "m.id = " + idmagasin + " and cp.id_produit = p.id and cp.id_commande = c.id and c.id_client = cl.id and c.id=" + reponse + " group by c.id order by statut DESC";
                    reader = command.ExecuteReader();
                    Console.WriteLine();
                    while (reader.Read())                           // parcours ligne par ligne
                    {
                        cpav = reader.GetString(3);
                    }
                    connection.Close();

                }
                else
                {
                    Environment.Exit(0);
                }
            } while (cpav != "VINV");

            string sommemax = "";
            List<string> listedesproduits = new List<string>();
            List<string> produits = new List<string>();
            List<string> quantites = new List<string>();//Liste pour les lignes de commandes
            string[] tabrep1 = { "1", "2", "3" };
            string reponse2 = "";
            string continuer = "oui";
            string leproduit = "";
            string notin = "-2,";
            int stock = -1;

            do
            {
                do
                {
                    do
                    {
                        connection.Open();
                        MySqlCommand command2 = connection.CreateCommand();
                        command2.CommandText = "select p.id, p.nom, im.quantite,p.prix,c.message_accompagnant from produits p, Inventaire_Magasin im,Magasins m,Commandes c,Commandes_Produits cp where " +
                            "m.id = " + idmagasin + " and c.id_magasin = m.id and im.id_magasin = m.id and p.id = im.id_produit and " +
                            "cp.id_produit = p.id and cp.id_commande = c.id and c.id = " + reponse + " ORDER BY cp.id; ";
                        MySqlDataReader reader2;
                        reader2 = command2.ExecuteReader();
                        Console.WriteLine("id    Produit         quantité restant    prix");
                        while (reader2.Read())                           // parcours ligne par ligne
                        {
                            Console.WriteLine(reader2.GetString(0) + "   " + reader2.GetString(1) + "     " + reader2.GetString(2) + " " + reader2.GetString(3));
                            sommemax = reader2.GetString(4);
                            listedesproduits.Add(reader2.GetString(0));
                        }

                        connection.Close();
                        Console.WriteLine("Que souhaitez vous mettre ?");
                        leproduit = Console.ReadLine();
                    } while (!listedesproduits.Contains(leproduit));

                    connection.Open();
                    MySqlCommand command1 = connection.CreateCommand();
                    command1.CommandText = "select quantite from produits p,magasins m,Inventaire_Magasin im where m.id=" + idmagasin + " and im.id_produit=" + leproduit + " and im.id_magasin = m.id and im.id_produit = p.id and p.categorie NOT IN ('FLEUR','ACCESSOIRE');";
                    MySqlDataReader reader1;
                    reader1 = command1.ExecuteReader();
                    while (reader1.Read())                           // parcours ligne par ligne
                    {
                        stock = reader1.GetInt32(0);
                    }
                    connection.Close();

                    Console.WriteLine("Combien souhaitez vous en mettre ?");
                    reponse2 = Console.ReadLine();

                } while (Convert.ToInt32(reponse2) > stock);

                produits.Add(leproduit);
                notin += leproduit + ",";
                quantites.Add(reponse2);
                Console.WriteLine("Souhaitez vous aujouter autre choses ? (oui , non)");
                continuer = Console.ReadLine();


            } while (continuer == "oui");

            for (int i = 0; i < produits.Count(); i++)
            {
                connection.Open();
                MySqlCommand command1 = connection.CreateCommand();
                command1.CommandText = "update Commandes_Produits set quantite= " + quantites[i] + " where id_commande=" + reponse + " AND id_produit = " + produits[i] + ";";
                command1.ExecuteNonQuery();
                connection.Close();
            }

            for (int i = 0; i < produits.Count(); i++)
            {
                connection.Open();
                MySqlCommand command1 = connection.CreateCommand();
                command1.CommandText = "update Inventaire_Magasin set quantite= quantite-" + quantites[i] + " where id_produit=" + produits[i] + " AND id_magasin=" + idmagasin + ";";
                command1.ExecuteNonQuery();
                connection.Close();
            }


            connection.Open();
            MySqlCommand command3 = connection.CreateCommand();
            command3.CommandText = "SELECT MAX(id) FROM Statuts_Commandes";
            int idstatut = Convert.ToInt32(command3.ExecuteScalar());
            string dateAujourdhui = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            // Définition de la requête paramétrée
            command3.CommandText = "INSERT INTO Statuts_Commandes (id, id_commande, code_etat, date_etat) VALUES (@id, @id_commande, @code_etat, @date_etat);";

            // Définition des paramètres de la commande
            command3.Parameters.AddWithValue("@id", idstatut + 1);
            command3.Parameters.AddWithValue("@id_commande", reponse);
            command3.Parameters.AddWithValue("@code_etat", "CC");
            command3.Parameters.AddWithValue("@date_etat", dateAujourdhui);

            // Exécution de la commande
            command3.ExecuteNonQuery();
            connection.Close();
            Console.WriteLine("Le nouveau statut a été ajouté avec succès !");
            Console.WriteLine("La commande a été mise à jour");
        }





        static void CPAV(MySqlConnection connection, string idmagasin)
        {
            Console.Clear();
            string cpav = "";
            string reponse = "";
            do
            {
                List<string> laliste = new List<string>();
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT cl.prenom,cl.nom,c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY " +
                    "sc.date_etat DESC LIMIT 1) as statut,(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE " +
                    "sc.id_commande = c.id) as date, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as produits,c.date_creation, c.date_livraison " +
                    "FROM Commandes c, magasins m, Produits p, Commandes_Produits cp,clients cl where c.id_magasin = m.id and " +
                    "m.id = " + idmagasin + " and cp.id_produit = p.id and cp.id_commande = c.id and c.id_client = cl.id group by c.id order by statut DESC";
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                Console.WriteLine();
                Console.WriteLine("Prenom    Nom     N° commande  Statut actuel       Date de maj      Produits commandés     Date de commande       Date de livraison");
                int abc = 0;
                while (reader.Read())                           // parcours ligne par ligne
                {
                    if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                    else Console.ForegroundColor = ConsoleColor.White;
                    abc += 1;
                    laliste.Add(Convert.ToString(reader.GetInt32(2)));

                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    Console.WriteLine(string.Join(" | ", values));
                    Console.WriteLine();


                }
                Console.ForegroundColor = ConsoleColor.White;
                connection.Close();
                reponse = "";
                Console.WriteLine("Vérifier les commandes CPAV ? (Selectionner le n° de commande) (1,2...; ou non)");
                reponse = Console.ReadLine();

                if (laliste.Contains(reponse)) //tableau contient reponse
                {
                    connection.Open();
                    command = connection.CreateCommand();
                    command.CommandText = "SELECT cl.prenom,cl.nom,c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY " +
                        "sc.date_etat DESC LIMIT 1) as statut,(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE " +
                        "sc.id_commande = c.id) as date, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as produits,c.date_creation, c.date_livraison " +
                        "FROM Commandes c, magasins m, Produits p, Commandes_Produits cp,clients cl where c.id_magasin = m.id and " +
                        "m.id = " + idmagasin + " and cp.id_produit = p.id and cp.id_commande = c.id and c.id_client = cl.id and c.id=" + reponse + " group by c.id order by statut DESC";
                    reader = command.ExecuteReader();
                    Console.WriteLine();
                    while (reader.Read())                           // parcours ligne par ligne
                    {
                        cpav = reader.GetString(3);
                    }
                    connection.Close();

                }
                else
                {
                    Environment.Exit(0);
                }
            } while (cpav != "CPAV");

            string sommemax = "";
            string vraisommemax = "";
            List<string> listedesproduits = new List<string>();
            List<string> produits = new List<string>();
            List<string> quantites = new List<string>();//Liste pour les lignes de commandes
            string[] tabrep1 = { "1", "2", "3" };
            string reponse2 = "";
            string continuer = "oui";
            string leproduit = "";
            string notin = "-2,";
            int stock = -1;

            do
            {
                do
                {
                    do
                    {
                        connection.Open();
                        MySqlCommand command2 = connection.CreateCommand();
                        command2.CommandText = "select p.id, p.nom, im.quantite,p.prix,c.message_accompagnant from produits p, Inventaire_Magasin im,Magasins m,Commandes c,Commandes_Produits cp where " +
                            "m.id = " + idmagasin + " and c.id_magasin = m.id and im.id_magasin = m.id and p.id = im.id_produit and " +
                            "cp.id_produit = p.id and cp.id_commande = c.id and c.id = " + reponse + " ORDER BY cp.id; ";
                        MySqlDataReader reader2;
                        reader2 = command2.ExecuteReader();
                        Console.WriteLine("id    Produit         quantité restant    prix");
                        while (reader2.Read())                           // parcours ligne par ligne
                        {
                            Console.WriteLine(reader2.GetString(0) + "   " + reader2.GetString(1) + "     " + reader2.GetString(2) + " " + reader2.GetString(3));
                            sommemax = reader2.GetString(4);
                            listedesproduits.Add(reader2.GetString(0));
                        }

                        int a = 0;
                        for (int i = sommemax.Length - 1; i >= 0; i--)
                        {
                            if (sommemax[i] != '-' && a == 0)
                            {
                                vraisommemax += sommemax[i];
                            }
                            else
                                a += 1;
                        }
                        char[] tableau = vraisommemax.ToCharArray();
                        Array.Reverse(tableau);
                        vraisommemax = new string(tableau);
                        Console.WriteLine("Budget max : " + vraisommemax);
                        vraisommemax = "";
                        
                        connection.Close();
                        Console.WriteLine("Que souhaitez vous mettre ?");
                        leproduit = Console.ReadLine();
                    } while (!listedesproduits.Contains(leproduit));

                    connection.Open();
                    MySqlCommand command1 = connection.CreateCommand();
                    command1.CommandText = "select quantite from produits p,magasins m,Inventaire_Magasin im where m.id=" + idmagasin + " and im.id_produit=" + leproduit + " and im.id_magasin = m.id and im.id_produit = p.id and p.categorie IN ('FLEUR','ACCESSOIRE');";
                    MySqlDataReader reader1;
                    reader1 = command1.ExecuteReader();
                    while (reader1.Read())                           // parcours ligne par ligne
                    {
                        stock = reader1.GetInt32(0);
                    }
                    connection.Close();

                    Console.WriteLine("Combien souhaitez vous en mettre ?");
                    reponse2 = Console.ReadLine();

                } while (Convert.ToInt32(reponse2) > stock);

                produits.Add(leproduit);
                notin += leproduit + ",";
                quantites.Add(reponse2);
                Console.WriteLine("Souhaitez vous aujouter autre choses ? (oui , non)");
                continuer = Console.ReadLine();


            } while (continuer == "oui");

            for (int i = 0; i < produits.Count(); i++)
            {
                connection.Open();
                MySqlCommand command1 = connection.CreateCommand();
                command1.CommandText = "update Commandes_Produits set quantite= " + quantites[i] + " where id_commande=" + reponse + " AND id_produit = " + produits[i] + ";";
                command1.ExecuteNonQuery();
                connection.Close();
            }

            for (int i = 0; i < produits.Count(); i++)
            {
                connection.Open();
                MySqlCommand command1 = connection.CreateCommand();
                command1.CommandText = "update Inventaire_Magasin set quantite= quantite-" + quantites[i] + " where id_produit=" + produits[i] + " AND id_magasin=" + idmagasin + ";";
                command1.ExecuteNonQuery();
                connection.Close();
            }


            connection.Open();
            MySqlCommand command3 = connection.CreateCommand();
            command3.CommandText = "SELECT MAX(id) FROM Statuts_Commandes";
            int idstatut = Convert.ToInt32(command3.ExecuteScalar());
            string dateAujourdhui = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            // Définition de la requête paramétrée
            command3.CommandText = "INSERT INTO Statuts_Commandes (id, id_commande, code_etat, date_etat) VALUES (@id, @id_commande, @code_etat, @date_etat);";

            // Définition des paramètres de la commande
            command3.Parameters.AddWithValue("@id", idstatut + 1);
            command3.Parameters.AddWithValue("@id_commande", reponse);
            command3.Parameters.AddWithValue("@code_etat", "CC");
            command3.Parameters.AddWithValue("@date_etat", dateAujourdhui);

            // Exécution de la commande
            command3.ExecuteNonQuery();
            connection.Close();
            Console.WriteLine("Le nouveau statut a été ajouté avec succès !");
            Console.WriteLine("La commande a été mise à jour");
        }




        static void Statutsmodif(MySqlConnection connection, string idmagasin)
        {
            Console.Clear();
            List<string> laliste = new List<string>();
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT cl.prenom,cl.nom,c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY " +
                "sc.date_etat DESC LIMIT 1) as statut,(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE " +
                "sc.id_commande = c.id) as date, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as produits,c.date_creation, c.date_livraison " +
                "FROM Commandes c, magasins m, Produits p, Commandes_Produits cp,clients cl where c.id_magasin = m.id and " +
                "m.id = " + idmagasin + " and cp.id_produit = p.id and cp.id_commande = c.id and c.id_client = cl.id group by c.id order by statut DESC";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            Console.WriteLine();
            Console.WriteLine("Prenom    Nom     N° commande  Statut actuel       Date de maj      Produits commandés     Date de commande       Date de livraison");
            int abc = 0;
            while (reader.Read())                           // parcours ligne par ligne
            {
                if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.White;
                abc += 1;
                laliste.Add(Convert.ToString(reader.GetInt32(2)));

                object[] values = new object[reader.FieldCount];
                reader.GetValues(values);
                Console.WriteLine(string.Join(" | ", values));
                Console.WriteLine();


            }
            Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
            Console.WriteLine("Souhaitez vous ajouter un nouveau statut d'une commande ? (Selectionner le n° de commande) (1,2...; ou non)");
            string reponse = "";
            reponse = Console.ReadLine();
            if (laliste.Contains(reponse)) //tableau contient reponse
            {
                connection.Open();
                command = connection.CreateCommand();
                command.CommandText = "SELECT cl.prenom,cl.nom,c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY " +
                    "sc.date_etat DESC LIMIT 1) as statut,(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE " +
                    "sc.id_commande = c.id) as date, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as produits,c.date_creation, c.date_livraison " +
                    "FROM Commandes c, magasins m, Produits p, Commandes_Produits cp,clients cl where c.id_magasin = m.id and " +
                    "m.id = " + idmagasin + " and cp.id_produit = p.id and cp.id_commande = c.id and c.id_client = cl.id and c.id=" + reponse + " group by c.id order by statut DESC";
                reader = command.ExecuteReader();
                Console.WriteLine();
                Console.WriteLine("Prenom    Nom     N° commande  Statut actuel       Date de maj      Produits commandés     Date de commande       Date de livraison");
                while (reader.Read())                           // parcours ligne par ligne
                {
                    laliste.Add(Convert.ToString(reader.GetInt32(2)));

                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    Console.WriteLine(string.Join(" | ", values));
                    Console.WriteLine();
                }
                connection.Close();
                string etat = "";
                Console.WriteLine("Par quoi souhaitez vous modifier l'état de la commande ?");
                etat = Console.ReadLine();


                connection.Open();
                command = connection.CreateCommand();
                command.CommandText = "SELECT MAX(id) FROM Statuts_Commandes";
                int idstatut = Convert.ToInt32(command.ExecuteScalar());
                string dateAujourdhui = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

                // Définition de la requête paramétrée
                command.CommandText = "INSERT INTO Statuts_Commandes (id, id_commande, code_etat, date_etat) VALUES (@id, @id_commande, @code_etat, @date_etat);";

                // Définition des paramètres de la commande
                command.Parameters.AddWithValue("@id", idstatut + 1);
                command.Parameters.AddWithValue("@id_commande", reponse);
                command.Parameters.AddWithValue("@code_etat", etat);
                command.Parameters.AddWithValue("@date_etat", dateAujourdhui);

                // Exécution de la commande
                command.ExecuteNonQuery();
                connection.Close();
                Console.WriteLine("Le nouveau statut a été ajouté avec succès !");

            }
            else
            {

            }
        }
        static void Inventaire(MySqlConnection connection, string idmagasin)
        {
            Console.Clear();
            List<string> laliste = new List<string>();
            string reponse = "";
            string quantite = "";
            string continuer = "oui";
            do
            {
                do
                {
                    connection.Open();
                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "select im.id, p.nom, im.quantite from produits p JOIN Inventaire_Magasin im ON p.id=im.id_produit JOIN Magasins m " +
                        "ON im.id_magasin = m.id where m.id = " + idmagasin + " ;";
                    MySqlDataReader reader;
                    reader = command.ExecuteReader();
                    Console.WriteLine();
                    Console.WriteLine("id  produit     quantite");
                    int abc = 0;
                    while (reader.Read())                           // parcours ligne par ligne
                    {
                        if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                        else Console.ForegroundColor = ConsoleColor.White;
                        abc += 1;
                        laliste.Add(Convert.ToString(reader.GetInt32(0)));

                        object[] values = new object[reader.FieldCount];
                        reader.GetValues(values);
                        Console.WriteLine(string.Join(" | ", values));
                        Console.WriteLine();
                    }
                    Console.ForegroundColor = ConsoleColor.White;
                    connection.Close();
                    Console.WriteLine("Quel produit souhaotez vous ajouter ?");
                    reponse = Console.ReadLine();
                } while (!laliste.Contains(reponse));
                Console.WriteLine("Quelle quantité souhaitez vous ajouter ?");
                quantite = Console.ReadLine();

                connection.Open();
                MySqlCommand command1 = connection.CreateCommand();
                command1.CommandText = "update Inventaire_Magasin im set quantite= quantite+" + quantite + " where im.id= " + reponse + " ;";
                command1.ExecuteNonQuery();
                connection.Close();
                Console.WriteLine("Souhaitez vous continuer à ajouter des produits ?");
                continuer = Console.ReadLine();

            } while (continuer == "oui");
         } 
    }
}
