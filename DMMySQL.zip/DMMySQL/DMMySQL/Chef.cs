﻿using System;
using MySql.Data.MySqlClient;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace DMMySQL
{
    public class Chef
    {
        public Chef()
        {
        }
        public static void Propriétaire(MySqlConnection connection)
        {
            MyImage fleurs = new MyImage("./Proprietaire.bmp");
            fleurs.Afficher();
            string pseudo = "";
            string mdppseudo = "";
            do
            {
                Console.WriteLine("Entrer pseudo");
                pseudo = Console.ReadLine();
                Console.WriteLine("Entrer mot de passe");
                mdppseudo = Console.ReadLine();

            } while (pseudo != mdppseudo || pseudo != "admin");
            Console.Clear();
            Alerte(connection);
            //Mettre un code où on une image attention s'affiche quand il y a moins de stock
            string[] tableaudereponse = { "1", "2", "3" };
            Console.WriteLine("Quelles statistiques souhaitez vous connaître ?");
            Console.WriteLine("1 boutique1" +
                "\n\n2 boutique2" +
                "\n\n3 Toutes les boutiques & informations générales" +
                "\n\n4 En cas de faillite...");
            string reponse = "";
            reponse = Console.ReadLine();
            switch (reponse)
            {
                case "1":
                    Boutique(connection, "Les douces fleurs de Sarah");
                    break;
                case "2":
                    Boutique(connection, "Les belles fleurs de Marie");
                    break;
                case "3":
                    Touteslesboutiques(connection);
                    break;
                case "4":
                    string reponsea = "";
                    Console.WriteLine("Souhaitez-vous vraiment mettre la clé sous la porte ?");
                    reponsea = Console.ReadLine();
                    if (reponsea=="oui")
                    {
                        Console.WriteLine("Êtes vous vraiment vraiment sûr ?");
                        reponsea = Console.ReadLine();
                        if (reponsea=="oui")
                        {
                            Faillite(connection);
                        }
                    }
                    break;
            }

        }
        static void Faillite(MySqlConnection connection)
        {
            connection.Open();
            MySqlCommand command1 = connection.CreateCommand();
            command1.CommandText = "DROP DATABASE FLEURS1;";
            command1.ExecuteNonQuery();
            connection.Close();
        }
        //Alerte le propriétaire en cas de manque de produits <15
        static void Alerte(MySqlConnection connection)
        {
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select im.id,p.nom,quantite,m.nom from Inventaire_magasin im join produits p on im.id_produit=p.id join magasins m on im.id_magasin=m.id order by im.id;";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            Console.WriteLine("id   produit       quantité    magasin");
            while (reader.Read())                           // parcours ligne par ligne
            {
                if (reader.GetInt32(2) < 16)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(reader.GetString(0) + " " + reader.GetString(1) + " " + reader.GetString(2) + " " + reader.GetString(3));
                    Console.ForegroundColor = ConsoleColor.White;
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("ATTENTION ");
                        Console.ForegroundColor = ConsoleColor.White;
                }
            }
            connection.Close();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
        }

        //Proprietaire des magasins


        static void Boutique(MySqlConnection connection, string nommagasin)
        {
            string[] tableaudereponse = { "1", "2", "3", "4" };
            Console.WriteLine("Que souhaitez vous connaître ?");
            Console.WriteLine("1 Prix moyen des produits achetés dans le magasin" +//C'est bon
                "\n\n2 Meilleur client du mois" +//C'est bon
                "\n\n3 Les produits ayant le plus de succès dans le magasin" + //C'est bon
                "\n\n4 Chiffre d\'affaires" + //c'est bon
                "\n\n5 Les produits les moins vendus du magasin" +
                "\n\n6 Categorie,vente,CA enegendré " +
                "\n\n7 Nombre de commandes" +
                "\n\n8 Clients & commandes" +//C'est bon
                "\n\n9 Produits en stock" +//C'est bon
                "\n\n10 Etat des commandes du magasin" +//C'est bon 
                "\n\n11 Toutes les statistiques");

            string reponse = "";
            reponse = Console.ReadLine();
            switch (reponse)
            {
                case "1":
                    string mois = "AND MONTH(c.date_creation)=";
                    string annee = "2023";
                    string reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Prixmoyen(connection, nommagasin, mois);
                    break;
                case "2":
                    mois = "AND MONTH(c.date_creation)=";
                    reponse1 = "";
                    annee = "2023";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Meilleurclient(connection, nommagasin, mois, annee);
                    break;
                case "3":
                    mois = "AND MONTH(c.date_creation)=";
                    annee = "2023";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Meilleurbouquet(connection, nommagasin, "BOUQUET_STANDARD", "DESC", mois, annee);
                    Meilleurbouquet(connection, nommagasin, "FLEUR", "DESC", mois, annee);
                    Meilleurbouquet(connection, nommagasin, "ACCESSOIRE", "DESC", mois, annee);
                    break;
                case "4":
                    mois = "AND MONTH(c.date_creation)=";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    CAMagasin(connection, nommagasin, mois);
                    break;
                case "5":
                    mois = "AND MONTH(c.date_creation)=";
                    annee = "2023";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Meilleurbouquet(connection, nommagasin, "BOUQUET_STANDARD", "", mois, annee);
                    Meilleurbouquet(connection, nommagasin, "FLEUR", "", mois, annee);
                    Meilleurbouquet(connection, nommagasin, "ACCESSOIRE", "", mois, annee);
                    break;
                case "6":
                    mois = "AND MONTH(c.date_creation)=";
                    annee = "2023";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Vente(connection, nommagasin, mois);
                    break;
                case "7":
                    mois = "AND MONTH(c.date_creation)=";
                    annee = "2023";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Nbcommandes(connection, nommagasin,mois);
                    break;
                case "8":
                    Clientsetcommandes(connection, nommagasin);
                    break;
                case "9":
                    Stockparmagasin(connection, nommagasin);
                    break;
                case "10":
                    Etat(connection, nommagasin);
                    break;
                case "11":
                    Stats(connection, nommagasin);
                    break;
            }
        }


        static void Touteslesboutiques(MySqlConnection connection)
        {
            Console.WriteLine("Que souhaitez vous connaître ?");
            Console.WriteLine("1 Prix moyen des produits achetés avec GRAPHIQUE" +
                "\n\n2 Meilleur client du mois" +
                "\n\n3 Les produits ayant le plus de succès" +
                "\n\n4 Magasin & chiffre d\'affaires avec GRAPHIQUE" +
                "\n\n5 Les produits les moins vendus du magasin" +
                "\n\n6 Categorie,vente,CA enegendré avec GRAPHIQUE" +
                "\n\n7 Nombre de commandes avec GRAPHIQUE" +
                "\n\n8 Clients & commandes" +//C'est bon
                "\n\n9 Produits en stock" +//C'est bon
                "\n\n10 Etat des commandes" +//C'est bon 
                "\n\n11 Produits ayant la même quantité dans les deux magasins" +
                "\n\n12 Produits ayant une quantité inférieure à la moyenne des quantités"+
                "\n\n13 Toutes les statistiques");

            string reponse = "";
            reponse = Console.ReadLine();
            switch (reponse)
            {
                case "1":
                    string mois = "AND MONTH(c.date_creation)=";
                    string annee = "2023";
                    string reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    PrixMoyentous(connection,mois);
                    break;
                case "2":
                    mois = "AND MONTH(c.date_creation)=";
                    annee = "2023";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Meilleurclienttous(connection, mois, annee);
                    break;
                case "3":
                    mois = "AND MONTH(c.date_creation)=";
                    annee = "2023";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Meilleurbouquetdesmagasins(connection, "BOUQUET_STANDARD", "DESC", mois, annee);
                    Meilleurbouquetdesmagasins(connection, "FLEUR", "DESC", mois, annee);
                    Meilleurbouquetdesmagasins(connection, "ACCESSOIRE", "DESC", mois, annee);
                    break;
                case "4":
                    mois = "AND MONTH(c.date_creation)=";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    CAMagasintous(connection, mois);
                    break;
                case "5":
                    mois = "AND MONTH(c.date_creation)=";
                    annee = "2023";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Meilleurbouquetdesmagasins(connection, "BOUQUET_STANDARD", "", mois, annee);
                    Meilleurbouquetdesmagasins(connection, "FLEUR", "", mois, annee);
                    Meilleurbouquetdesmagasins(connection, "ACCESSOIRE", "", mois, annee);

                    break;
                case "6":
                    mois = "AND MONTH(c.date_creation)=";
                    annee = "2023";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Ventetous(connection, mois);
                    break;
                case "7":
                    mois = "AND MONTH(c.date_creation)=";
                    annee = "2023";
                    reponse1 = "";
                    Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
                    reponse1 = Console.ReadLine();
                    if (reponse1 == "mois")
                    {
                        Console.WriteLine("De quel mois ?");
                        mois += Console.ReadLine();
                    }
                    else
                        mois = "";
                    Nbcommandestous(connection,mois);
                    break;
                case "8":
                    Clientsetcommandestous(connection);
                    break;
                case "9":
                    Stocktous(connection);
                    break;
                case "10":
                    Etattous(connection);
                    break;
                case "11":
                    Quantitesegal(connection);
                    break;
                case "12":
                    DessousMoyenne(connection);
                    break;
                case "13":
                    Statstous(connection);
                    break;
            }
        }


        ////////Requetes Chef////////////////////////////////////////////////////////////////////////////////////////////
        ////////Requetes Chef////////////////////////////////////////////////////////////////////////////////////////////


        ///////////////////////////////////////////////////////////Prix moyen des bouquets achetés

        //Renvoie le prix moyen des bouquets standards achetés dans une boutique
        static List<string> Prixmoyen(MySqlConnection connection, string nommagasin, string mois)
        {
            Console.Clear();
            List<string> donnees = new List<string>();
            connection.Open();
            Console.WriteLine("Prix moyen des produits achetés :");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select p.categorie, sum(p.prix*cp.quantite)/sum(cp.quantite) as moyennedesbouquets from Produits p, Commandes_Produits cp, Commandes c, Magasins m where cp.id_commande=c.id and cp.id_produit =p.id and c.id_magasin=m.id " + mois + " AND YEAR(c.date_creation)=2023 and m.nom=\'" + nommagasin + "\' GROUP BY p.categorie ORDER BY p.categorie;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcourir ligne par ligne
            {
                Console.WriteLine(reader.GetString(0)+" "+reader.GetDouble(1)+"€");
                donnees.Add(reader.GetString(1));
            }
            connection.Close();
            return (donnees);
        }


        //Renvoie le prix moyen des bouquets standards achetés de toutes les boutiques
        static List<string> PrixMoyentous(MySqlConnection connection,string mois)
        {
            Console.Clear();
            List<string> donnees = new List<string>();
            List<double> lesca = new List<double>();
            connection.Open();
            Console.WriteLine("Prix moyen des produits achetés :");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select p.categorie, sum(p.prix*cp.quantite)/sum(cp.quantite) as moyennedesbouquets from Produits p, Commandes_Produits cp, Commandes c where cp.id_commande=c.id and cp.id_produit =p.id " + mois + " AND YEAR(c.date_creation)=2023 GROUP BY p.categorie ORDER BY p.categorie;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.WriteLine(reader.GetString(0) + " " + reader.GetDouble(1)+"€");
                donnees.Add(reader.GetString(1));
                lesca.Add(reader.GetDouble(1));
            }
            connection.Close();
            Console.WriteLine("\n\n" + "GRAPHIQUE :");
            double a = lesca[0];
            double b = lesca[1];
            double c = lesca[2];
            while (a > 100 || b > 100||c>100)
            {
                a = a / 2;
                b = b / 2;
                c = c / 2;
            }
            Console.ForegroundColor = ConsoleColor.Blue;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(a)+1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine(" Prix moyen BOUQUET_STANDARD");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(b)+1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine("Prix moyen FLEUR");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(c)+1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine(" Prix moyen ACCESSOIRE");
            Console.ForegroundColor = ConsoleColor.White;
            return (donnees);
        }





        ///////////////////////////////////////////////////////////Meilleur bouquet/fleur/accessoire d'une boutique donnée

        //Renvoie le meilleur bouquet d'une boutique donnée
        static List<string> Meilleurbouquet(MySqlConnection connection, string nommagasin, string categorie, string ordre, string mois, string annee)
        // moyenne de prix de journée
        {
            Console.Clear();
            List<string> donnees = new List<string>();
            connection.Open();
            Console.WriteLine("Le meilleur bouquet est :");
            //int premiereValeur = Dico.Values.First();
            string commande = "SELECT p.nom AS nom_produit, SUM(cp.quantite) AS quantite_vendue, (SUM(cp.quantite)*p.prix) AS CA FROM Commandes_Produits cp, Produits p, Commandes c, Magasins m WHERE cp.id_produit = p.id AND cp.id_commande = c.id and c.id_magasin = m.id and m.nom =\'" + nommagasin + "\' and p.categorie= \'" + categorie + "\' " + mois + " AND YEAR(c.date_creation)=@annee GROUP BY p.id, p.nom order by quantite_vendue " + ordre + " LIMIT 1;";
            MySqlCommand command = new MySqlCommand(commande, connection);
            command.Parameters.AddWithValue("@annee", annee);
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.Write(reader.GetString(0) + " ");
                Console.WriteLine(reader.GetString(1) + " quantité vendue");
                Console.WriteLine(reader.GetString(2) + "€ de CA");
                donnees.Add(reader.GetString(0));
                donnees.Add(reader.GetString(1));
                donnees.Add(reader.GetString(2));
            }
            connection.Close();
            return donnees;
        }



        //Renvoie le meilleur bouquet de toutes les boutiques
        static List<string> Meilleurbouquetdesmagasins(MySqlConnection connection, string categorie, string ordre, string mois, string annee)
        // moyenne de prix de journée
        {
            Console.Clear();
            List<string> donnees = new List<string>();
            connection.Open();
            Console.WriteLine("Le meilleur bouquet est :");
            //int premiereValeur = Dico.Values.First();
            string commande = "SELECT p.nom AS nom_produit, SUM(cp.quantite) AS quantite_vendue,(SUM(cp.quantite)*p.prix) AS CA FROM Commandes_Produits cp, Produits p, Commandes c, Magasins m WHERE cp.id_produit = p.id AND cp.id_commande = c.id and c.id_magasin = m.id AND p.categorie=  \'" + categorie + "\' " + mois + " AND YEAR(c.date_creation)=@annee GROUP BY p.id, p.nom order by quantite_vendue " + ordre + " LIMIT 1;";
            MySqlCommand command = new MySqlCommand(commande, connection);
            command.Parameters.AddWithValue("@annee", annee);
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.Write(reader.GetString(0) + " ");
                Console.WriteLine(reader.GetInt32(1) + " quantité vendue");
                Console.WriteLine(reader.GetString(2) + "€ de CA");
                donnees.Add(reader.GetString(0));
                donnees.Add(reader.GetString(1));
                donnees.Add(reader.GetString(2));
            }
            connection.Close();


            return donnees;
        }






        ///////////////////////////////////////////////////////////Categorie, vente, CA

        //Renvoie le nombre de vente par categorie d'un magasin
        static List<string> Vente(MySqlConnection connection, string nommagasin, string mois)
        // moyenne de prix de journée
        {
            Console.Clear();
            List<string> donnees = new List<string>();
            connection.Open();
            Console.WriteLine("Vente par catégorie");
            //int premiereValeur = Dico.Values.First();
            string commande = "SELECT p.categorie AS categorie, SUM(cp.quantite) AS quantite_vendue, SUM(cp.quantite * p.prix) AS CA " +
                "FROM Commandes_Produits cp, Produits p, Commandes c, Magasins m " +
                "WHERE cp.id_produit = p.id AND cp.id_commande = c.id AND c.id_magasin = m.id AND m.nom = \'" + nommagasin + "\' " + mois + " AND YEAR(c.date_creation) = 2023 " +
                "GROUP BY p.categorie " +
                "ORDER BY p.categorie; ";
            MySqlCommand command = new MySqlCommand(commande, connection);
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcours ligne par ligne
            {
                Console.Write(reader.GetString(0) + " ");
                Console.Write(reader.GetString(1) + "quantité vendue ");
                Console.WriteLine(reader.GetString(2) + " de CA");
                donnees.Add(reader.GetString(1));
                donnees.Add(reader.GetString(2));
            }
            connection.Close();
            return donnees;
        }



        //Renvoie le nombre de vente par categorie de tous les magasins
        static List<string> Ventetous(MySqlConnection connection, string mois)
        // moyenne de prix de journée
        {
            Console.Clear();
            List<string> donnees = new List<string>();
            List<double> lesca = new List<double>();
            List<double> nbvente = new List<double>();
            connection.Open();
            Console.WriteLine("Vente par catégorie");
            //int premiereValeur = Dico.Values.First();
            string commande = "SELECT p.categorie AS categorie, SUM(cp.quantite) AS quantite_vendue, SUM(cp.quantite * p.prix) AS CA " +
                "FROM Commandes_Produits cp, Produits p, Commandes c, Magasins m " +
                "WHERE cp.id_produit = p.id AND cp.id_commande = c.id AND c.id_magasin = m.id " + mois + " AND YEAR(c.date_creation) = 2023 " +
                "GROUP BY p.categorie " +
                "ORDER BY p.categorie; ";
            MySqlCommand command = new MySqlCommand(commande, connection);
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcours ligne par ligne
            {
                Console.Write(reader.GetString(0) + " ");
                Console.Write(reader.GetString(1) + "quantité vendue ");
                Console.WriteLine(reader.GetString(2) + " de CA");
                donnees.Add(reader.GetString(1));
                donnees.Add(reader.GetString(2));
                lesca.Add(reader.GetDouble(2));
                nbvente.Add(reader.GetDouble(1));
            }
            connection.Close();
            Console.WriteLine("\n\n" + "GRAPHIQUE Nb vente :");
            double a = lesca[0];
            double b = lesca[1];
            double c = lesca[2];
            double d = nbvente[0];
            double e = nbvente[1];
            double f = nbvente[2];

            while (a > 100 || b > 100 || c > 100)
            {
                a = a / 2;
                b = b / 2;
                c = c / 2;
            }

            while (d > 100 || e > 100 || f > 100)
            {
                d = d / 2;
                e = e / 2;
                f = f / 2;
            }
            Console.ForegroundColor = ConsoleColor.Blue;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(d)+1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine(" Nb vente BOUQUET_STANDARD");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(e)+1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine(" Nb vente FLEUR");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(f)+1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine(" Nb vente ACCESSOIRE");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();
            Console.WriteLine("\n\n" + "GRAPHIQUE CA par catégorie :");
            Console.ForegroundColor = ConsoleColor.Blue;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(a)+1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine(" CA BOUQUET_STANDARD");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(b)+1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine(" CA FLEUR");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(c)+1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine(" CA ACCESSOIRE");
            Console.ForegroundColor = ConsoleColor.White;


            return donnees;
        }






        /////////////////////////////////////////////////////////////////////////Meilleur client

        //renvoie le meilleur client pour un magasin
        static List<string> Meilleurclient(MySqlConnection connection, string nommagasin, string mois, string annee)
        // moyenne de prix de journée
        {
            Console.Clear();
            connection.Open();
            List<string> donnees = new List<string>();
            string commande = "SELECT cl.nom,cl.prenom, COUNT(DISTINCT c.id) AS nb_commandes,sum(p.prix*cp.quantite) as CA FROM Commandes c, Clients cl, Magasins m, Produits p, Commandes_Produits cp" +
                " WHERE m.nom = \'" + nommagasin + "\' and c.id_client = cl.id and c.id_magasin=m.id and cp.id_commande=c.id and cp.id_produit=p.id " + mois + " AND YEAR(c.date_creation) = @annee " +
                "GROUP BY cl.id ORDER BY nb_commandes DESC LIMIT 1;";
            MySqlCommand command = new MySqlCommand(commande, connection);//On fait ça car sinon ça marche pas avec les mois qu'on rentre
            command.Parameters.AddWithValue("@annee", annee);
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.WriteLine(reader.GetString(0) + " " + reader.GetString(1) + " : " + reader.GetInt32(2) + " commmandes effectuées "
                    + reader.GetString(3) + "€ de CA engendré");
                donnees.Add(reader.GetString(0));
                donnees.Add(reader.GetString(1));
                donnees.Add(reader.GetString(2));
                donnees.Add(reader.GetString(3));
            }
            connection.Close();
            return donnees;
        }

        //Renvoie le meilleur client pour tous les magasins
        static List<string> Meilleurclienttous(MySqlConnection connection, string mois, string annee)
        // moyenne de prix de journée
        {
            Console.Clear();
            connection.Open();
            List<string> donnees = new List<string>();
            string commande = "SELECT cl.nom,cl.prenom, COUNT(DISTINCT c.id) AS nb_commandes, sum(p.prix*cp.quantite) as CA FROM Commandes c, Clients cl, Magasins m, Produits p, Commandes_Produits cp WHERE " +
                "c.id_client = cl.id and cp.id_commande=c.id and cp.id_produit=p.id " + mois + " AND YEAR(c.date_creation) = @annee GROUP BY cl.id ORDER BY nb_commandes DESC LIMIT 1;";
            MySqlCommand command = new MySqlCommand(commande, connection);//On fait ça car sinon ça marche pas avec les mois qu'on rentre
            command.Parameters.AddWithValue("@annee", 2023);
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.WriteLine(reader.GetString(0) + " " + reader.GetString(1) + " : " + reader.GetInt32(2) + " commmandes effectuées"
                    + reader.GetString(3) + "€ de CA engendré");
                donnees.Add(reader.GetString(0));
                donnees.Add(reader.GetString(1));
                donnees.Add(reader.GetString(2));
                donnees.Add(reader.GetString(3));
            }
            connection.Close();
            return (donnees);
        }




        /////////////////////////////////////////////////////////////////////////Chiffre d'affaire

        //Méthode pour obtenir le chiffre d'affaires d'un magasin
        static double CAMagasin(MySqlConnection connection, string nommagasin, string mois) //Faire attention CA mois/annee
        {
            Console.Clear();
            connection.Open();
            Console.WriteLine("CA du magasin : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select sum(p.prix*cp.quantite) as CA from Produits p, Commandes_Produits cp, Commandes c, Magasins m where cp.id_commande=c.id and cp.id_produit =p.id and c.id_magasin=m.id " + mois + " AND YEAR(c.date_creation) = 2023 and m.nom=\'" + nommagasin + "\';";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            double donnee = 0;
            while (reader.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.WriteLine(reader.GetDouble(0) + "€ de CA");
                donnee = reader.GetDouble(0);
            }
            connection.Close();
            return (donnee);
        }

        //Méthode pour obtenir le chiffre d'affaires de tous les magasins réunis
        static List<string> CAMagasintous(MySqlConnection connection, string mois)
        {
            Console.Clear();
            List<double> lesca = new List<double>();
            List<string> donnees = new List<string>();
            connection.Open();
            Console.WriteLine("CA des magasins : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select m.nom, sum(p.prix*cp.quantite) as CA from Produits p, Commandes_Produits cp, Commandes c, Magasins m where cp.id_commande=c.id and cp.id_produit =p.id and c.id_magasin=m.id " + mois + " AND YEAR(c.date_creation) = 2023 group by m.id UNION select 'tous' as message,sum(p.prix * cp.quantite) as CA from Produits p, Commandes_Produits cp, Commandes c, Magasins m where cp.id_commande = c.id and cp.id_produit = p.id and c.id_magasin = m.id " + mois + " AND YEAR(c.date_creation) = 2023 ; ";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.WriteLine(reader.GetString(0) + " " + reader.GetDouble(1) + "€ de CA");
                donnees.Add(reader.GetString(0));
                donnees.Add(reader.GetString(1));
                lesca.Add(reader.GetDouble(1));
            }
            double a = lesca[0];
            double b = lesca[1];
            while (a > 100 || b > 100)
            {
                a = a / 2;
                b = b / 2;
            }
            Console.ForegroundColor = ConsoleColor.Blue;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(a); j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine("Les douces fleurs de Sarah");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(b); j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine("Les belles fleurs de Marie");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
            return donnees;

        }


        /////////////////////////////////////////////////////////////////////////Nombre de commandes

        //Nombre de commandes d'un magasin
        static int Nbcommandes(MySqlConnection connection, string nommagasin, string mois)
        {
            Console.Clear();
            connection.Open();
            Console.WriteLine("Nombre de commandes du magasin : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select count(*) from Commandes c JOIN Magasins m on c.id_magasin=m.id " + mois + " and YEAR(date_creation)=2023 and m.nom=\'" + nommagasin + "\';";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            int donnee = 0;
            while (reader.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.WriteLine(reader.GetInt32(0) + " commandes effectuées");
                donnee = reader.GetInt32(0);
            }
            connection.Close();
            return (donnee);
        }

        //Nombre de commandes de tous les magasins
        static List<string> Nbcommandestous(MySqlConnection connection, string mois)
        {
            Console.Clear();
            List<string> donnees = new List<string>();
            List<double> lesca = new List<double>();
            connection.Open();
            Console.WriteLine("CA des magasins : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select m.nom, count(*) from Commandes c JOIN Magasins m on c.id_magasin=m.id " + mois + " and YEAR(date_creation)=2023 group by m.nom union " +
                "select 'tous' as message, count(*) from Commandes c JOIN Magasins m on c.id_magasin=m.id " + mois + " and YEAR(date_creation)=2023;";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())                           // parcours ligne par ligne
            {
                //moyenne = reader.GetDouble(0);  // récupération de la 1nde colonne (selon la requête !)
                Console.WriteLine(reader.GetString(0) + " " + reader.GetInt32(1) + " commandes effectuées");
                donnees.Add(reader.GetString(0));
                donnees.Add(reader.GetString(1));
                lesca.Add(reader.GetDouble(1));
            }
            connection.Close();
            Console.WriteLine("\n\n" + "GRAPHIQUE :");
            double a = lesca[0];
            double b = lesca[1];
            while (a > 100 || b > 100)
            {
                a = a / 2;
                b = b / 2;
            }
            Console.ForegroundColor = ConsoleColor.Blue;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(a) + 1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine(" Les douces fleurs de Sarah");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < Convert.ToInt32(b) + 1; j++)
                {
                    Console.Write("*");

                }
                Console.WriteLine();
            }
            Console.WriteLine("Les belles fleurs de Marie");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;
            return donnees;
        }

        ///////////////////////////////////////////////////////////////////////////Clients et commandes

        //Méthode pour obtenir les commandes des clients par magasin
        static void Clientsetcommandes(MySqlConnection connection, string nommagasin)
        {
            Console.Clear();
            connection.Open();
            Console.WriteLine("Clients et commandes : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT cl.id,cl.nom,prenom,telephone,courriel,adresse_facturation,statut_fidélité,c.id as 'numéro de commande',m.nom, c.date_creation,c.adresse_livraison,c.message_accompagnant,c.date_livraison, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as 'Produits commandés' FROM produits p, commandes c, clients cl, Commandes_Produits cp, Magasins m WHERE c.id_client = cl.id AND cp.id_commande = c.id AND cp.id_produit = p.id AND c.id_magasin = m.id AND m.nom =\'" + nommagasin + "\'GROUP BY c.id order by statut_fidélité;";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            int abc = 0;
            while (reader.Read())
            {
                if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.White;
                abc += 1;
                object[] values = new object[reader.FieldCount];
                reader.GetValues(values);
                Console.WriteLine(string.Join(" | ", values));
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
        }

        //Méthode pour obtenir les commandes des clients de tous les magasins
        static void Clientsetcommandestous(MySqlConnection connection)
        {
            Console.Clear();
                connection.Open();
                Console.WriteLine("Clients et commandes : ");
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT cl.id,cl.nom,prenom,telephone,courriel,adresse_facturation,statut_fidélité,c.id as 'numéro de commande',m.nom, c.date_creation,c.adresse_livraison,c.message_accompagnant,c.date_livraison, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as 'Produits commandés' FROM produits p, commandes c, clients cl, Commandes_Produits cp, Magasins m WHERE c.id_client = cl.id AND cp.id_commande = c.id AND cp.id_produit = p.id AND c.id_magasin = m.id GROUP BY c.id order by statut_fidélité;";
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                int abc = 0;
                while (reader.Read())
                {
                    if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                    else Console.ForegroundColor = ConsoleColor.White;
                    abc += 1;
                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    Console.WriteLine(string.Join(" | ", values));
                    Console.WriteLine();
                }
                Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
        }

        /////////////////////////////////////////////////////////////////////////Stock des magasins

        //Stock par magasin
        static void Stockparmagasin(MySqlConnection connection, string nommagasin)
        {
            Console.Clear();
            connection.Open();
            Console.WriteLine("Stock du magasin: ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select p.nom,p.prix,p.categorie,im.quantite from produits p, Inventaire_magasin im, Magasins m where im.id_magasin=m.id and im.id_produit=p.id and m.nom=\'" + nommagasin + "\';";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            Console.WriteLine("Nom du bouquet      prix   categorie    quantite\n");
            int abc = 0;
            while (reader.Read())
            {
                if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.White;
                abc += 1;
                object[] values = new object[reader.FieldCount];
                reader.GetValues(values);
                Console.WriteLine(string.Join(" | ", values));
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
        }

        //Stock de tous les magasins
        static void Stocktous(MySqlConnection connection)
        {
            Console.Clear();
            connection.Open();
            Console.WriteLine("Stock des magasins : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "select p.nom,p.prix,p.categorie,im.quantite,m.nom from produits p, Inventaire_magasin im, Magasins m where im.id_magasin=m.id and im.id_produit=p.id order by m.id;";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            Console.WriteLine("Nom du bouquet      prix   categorie    quantite     magasin\n");
            int abc = 0;
            while (reader.Read())
            {
                if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.White;
                abc += 1;
                object[] values = new object[reader.FieldCount];
                reader.GetValues(values);
                Console.WriteLine(string.Join(" | ", values));
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
        }




        /////////////////////////////////////////////////////////////////////////Etat actuel des commandes

        //Etat des commandes d'un magasin
        static void Etat(MySqlConnection connection, string nommagasin)
        {
            Console.Clear();
            connection.Open();
            Console.WriteLine("Etat actuel des commandes du magasin : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY sc.date_etat DESC LIMIT 1) as 'etat',(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE sc.id_commande = c.id) as 'date' FROM Commandes c, magasins m where c.id_magasin = m.id and m.nom=\'" + nommagasin + "\'order by etat; ";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            Console.WriteLine("Numero de commande   état actuel   derniere maj\n");
            int abc = 0;
            while (reader.Read())
            {
                if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.White;
                abc += 1;
                object[] values = new object[reader.FieldCount];
                reader.GetValues(values);
                Console.WriteLine(string.Join(" | ", values));
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
        }

        //Etat de tous les magasins
        static void Etattous(MySqlConnection connection)
        {
            Console.Clear();
            connection.Open();
            Console.WriteLine("Etat actuel des commandes : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY sc.date_etat DESC LIMIT 1) as 'etat',(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE sc.id_commande = c.id) as 'date', m.nom FROM Commandes c, magasins m where c.id_magasin = m.id order by etat; ";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            Console.WriteLine("Numero de commande   état actuel   derniere maj          Magasin\n");
            int abc = 0;
            while (reader.Read())
            {
                if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.White;
                abc += 1;
                object[] values = new object[reader.FieldCount];
                reader.GetValues(values);
                Console.WriteLine(string.Join(" | ", values));
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
        }

        //Etat de tous les magasins
        static void Quantitesegal(MySqlConnection connection)
        {
            Console.Clear();
            connection.Open();
            Console.WriteLine("Produits avec la même quantité dans les deux magasins : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT DISTINCT nom, im1.quantite AS quantite_magasin_1 FROM Inventaire_Magasin im1 JOIN Inventaire_Magasin im2 ON im1.id_produit = im2.id_produit AND im1.id_magasin != im2.id_magasin JOIN Produits p ON im1.id_produit=p.id WHERE im1.quantite = im2.quantite;";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            Console.WriteLine("Nom     quantité\n");
            int abc = 0;
            while (reader.Read())
            {
                if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.White;
                abc += 1;
                object[] values = new object[reader.FieldCount];
                reader.GetValues(values);
                Console.WriteLine(string.Join(" | ", values));
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
        }

        //Etat de tous les magasins
        static void DessousMoyenne(MySqlConnection connection)
        {
            Console.Clear();
            connection.Open();
            Console.WriteLine("Produits dont la quantité se trouve en dessous de la moyenne des quantités des produits : ");
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT p.nom, im.quantite FROM Inventaire_Magasin im JOIN Produits p ON im.id_produit=p.id WHERE im.quantite<(SELECT AVG(im.quantite) FROM Inventaire_Magasin im);";
            MySqlDataReader reader;
            reader = command.ExecuteReader();
            Console.WriteLine("Nom     quantité\n");
            int abc = 0;
            while (reader.Read())
            {
                if (abc % 2 == 0) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.White;
                abc += 1;
                object[] values = new object[reader.FieldCount];
                reader.GetValues(values);
                Console.WriteLine(string.Join(" | ", values));
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.White;
            connection.Close();
        }











        /////////////////////////////////////////////////////////////////////////Toutes les stats
        public static void Stats(MySqlConnection connection, string nommagasin)
        {
            Console.Clear();
            string mois = "AND MONTH(c.date_creation)=";
            string annee = "2023";
            string reponse1 = "";
            Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
            reponse1 = Console.ReadLine();
            if (reponse1 == "mois")
            {
                Console.WriteLine("De quel mois ?");
                mois += Console.ReadLine();
            }
            else
                mois = " ";


            string path = "./Statistiques/Statistiques" + nommagasin+mois+" "+annee+".csv"; //chemin pour créer le dossier

            using (StreamWriter sw = new StreamWriter(path, true)) //Créer ou ouvrir le fichier stats3.csv en mode écriture
            {
                //MySqlCommand command = connection.CreateCommand();
                //command.CommandText = "SELECT cl.id,cl.nom,prenom,telephone,courriel,adresse_facturation,statut_fidélité,c.id as 'numéro de commande',m.nom, c.date_creation,c.adresse_livraison,c.message_accompagnant,c.date_livraison, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as 'Produits commandés' FROM produits p, commandes c, clients cl, Commandes_Produits cp, Magasins m WHERE c.id_client = cl.id AND cp.id_commande = c.id AND cp.id_produit = p.id AND c.id_magasin = m.id GROUP BY c.id order by statut_fidélité;";
                //MySqlDataReader reader;
                //reader = command.ExecuteReader();



                
                for (int i = 0; i < 17; i++)
                {
                    sw.Write(mois[mois.Length-1]+" "+annee+" ");
                }
                sw.Write("\n" + nommagasin);
                for (int i = 0; i < 5; i++)
                {
                    sw.Write(nommagasin);
                }
                sw.Write("\n");
                sw.Write("\n");



                //Première rangé
                sw.Write("CA : ;" + CAMagasin(connection, nommagasin, mois) + ";;");
                Console.Clear();
                sw.Write("Bouquet le plus vendu : ;" + Meilleurbouquet(connection, nommagasin, "BOUQUET_STANDARD", "DESC", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("Fleur la plus vendu : ;" + Meilleurbouquet(connection, nommagasin, "FLEUR", "DESC", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("Accessoire le plus vendu : ;" + Meilleurbouquet(connection, nommagasin, "ACCESSOIRE", "DESC", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("\n");
                sw.Write("Nombre de commandes : ;" + Nbcommandes(connection, nommagasin, mois) + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquet(connection, nommagasin, "BOUQUET_STANDARD", "DESC", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquet(connection, nommagasin, "FLEUR", "DESC", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquet(connection, nommagasin, "ACCESSOIRE", "DESC", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("\n ; ; ;");
                sw.Write("CA : ;" + Meilleurbouquet(connection, nommagasin, "BOUQUET_STANDARD", "DESC", mois, annee)[2] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + Meilleurbouquet(connection, nommagasin, "FLEUR", "DESC", mois, annee)[2] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + Meilleurbouquet(connection, nommagasin, "ACCESSOIRE", "DESC", mois, annee)[2] + ";;");
                Console.Clear();


                sw.Write("\n");
                sw.Write("\n");
                sw.Write("\n");
                sw.Write("\n");


                //Deuxième rangé
                List<string> donnee = Meilleurclient(connection, nommagasin, mois, annee);
                sw.Write("Meilleur client : ;" + donnee[0] + " " + donnee[1] + ";;");
                Console.Clear();
                sw.Write("Bouquet le moins vendu : ;" + Meilleurbouquet(connection, nommagasin, "BOUQUET_STANDARD", "", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("Fleur la moins vendu : ;" + Meilleurbouquet(connection, nommagasin, "FLEUR", "", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("Accessoire le moins vendu : ;" + Meilleurbouquet(connection, nommagasin, "ACCESSOIRE", "", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("\n");
                sw.Write("Nombre de commandes : ;" + donnee[2] + ";;");
                sw.Write("quantite vendue : ;" + Meilleurbouquet(connection, nommagasin, "BOUQUET_STANDARD", "", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquet(connection, nommagasin, "FLEUR", "", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquet(connection, nommagasin, "ACCESSOIRE", "", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("\n");
                sw.Write("CA engendre : ;" + donnee[3] + ";;");
                sw.Write("CA : ;" + Meilleurbouquet(connection, nommagasin, "BOUQUET_STANDARD", "", mois, annee)[2] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + Meilleurbouquet(connection, nommagasin, "FLEUR", "", mois, annee)[2] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + Meilleurbouquet(connection, nommagasin, "ACCESSOIRE", "", mois, annee)[2] + ";;");
                Console.Clear();


                sw.Write("\n");
                sw.Write("\n");
                sw.Write("\n");
                sw.Write("\n");


                //Troisième rangé
                List<string> donnee1 = Prixmoyen(connection, nommagasin, mois);
                Console.Clear();
                List<string> donnee2 = Vente(connection, nommagasin, mois);
                Console.Clear();
                sw.Write("Prix Moyen Bouquets : ;" + donnee1[0] + ";;");
                sw.Write("Bouquets vendus ;" + ";;");
                sw.Write("Fleurs vendues ;" + ";;");
                sw.Write("Accessoires vendus ;" + ";;");
                sw.Write("\n");
                sw.Write("Prix Moyen Fleurs ;" + donnee1[1] + ";;");
                sw.Write("quantite vendue : ;" + donnee2[0] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + donnee2[2] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + donnee2[4] + ";;");
                Console.Clear();
                sw.Write("\n");
                sw.Write("Prix Moyen Accessoires : ;" + donnee1[2] + ";;");
                sw.Write("CA : ;" + donnee2[1] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + donnee2[3] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + donnee2[5] + ";;");
                Console.Clear();

                //    //object[] values = new object[reader.FieldCount];
                //    //    reader.GetValues(values);
                //    //    Console.WriteLine(string.Join(" | ", values));
                //    //    Console.WriteLine();
                //    //    sw.Write(string.Join(";", values));
                //    //    sw.Write("'\n");
            }

            string path1 = "./Statistiques/Clients" + nommagasin+".csv"; //chemin pour créer le dossier

            using (StreamWriter sw = new StreamWriter(path1, true)) //Créer ou ouvrir le fichier stats.csv en mode écriture
            {
                sw.Write("id;nom;prenom;telephone;courriel;adresse facturation;fidelite;id commande;magasin;date de commande;adresse livraison;message;date liraison;produits");
                sw.Write('\n');
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT cl.id,cl.nom,prenom,telephone,courriel,adresse_facturation,statut_fidélité,c.id as 'numéro de commande',m.nom, c.date_creation,c.adresse_livraison,c.message_accompagnant,c.date_livraison, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as 'Produits commandés' FROM produits p, commandes c, clients cl, Commandes_Produits cp, Magasins m WHERE c.id_client = cl.id AND cp.id_commande = c.id AND cp.id_produit = p.id AND c.id_magasin = m.id AND m.nom =\'" + nommagasin + "\'GROUP BY c.id order by statut_fidélité;";
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    sw.Write(string.Join(";", values));
                    sw.Write('\n');
                }
                connection.Close();
            }



            string path3 = "./Statistiques/Stock" + nommagasin + ".csv"; //chemin pour créer le dossier

            using (StreamWriter sw = new StreamWriter(path3, true)) //Créer ou ouvrir le fichier stats.csv en mode écriture
            {
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "select p.nom,p.prix,p.categorie,im.quantite from produits p, Inventaire_magasin im, Magasins m where im.id_magasin=m.id and im.id_produit=p.id and m.nom=\'" + nommagasin + "\';";
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                sw.Write("Nom du bouquet;prix;categorie;quantite\n");
                sw.Write('\n');
                while (reader.Read())
                {
                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    sw.Write(string.Join(";", values));
                    sw.Write('\n');
                }
                connection.Close();
            }


            string path4 = "./Statistiques/Etatdescommandesactuel" + nommagasin + ".csv"; //chemin pour créer le dossier

            using (StreamWriter sw = new StreamWriter(path4, true)) //Créer ou ouvrir le fichier stats.csv en mode écriture
            {
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY sc.date_etat DESC LIMIT 1) as 'etat',(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE sc.id_commande = c.id) as 'date' FROM Commandes c, magasins m where c.id_magasin = m.id and m.nom=\'" + nommagasin + "\'order by etat; ";
                MySqlDataReader reader;
                reader = command.ExecuteReader();

                sw.Write("Numero de commande;état actuel;derniere maj");
                sw.Write('\n');
                while (reader.Read())
                {
                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    sw.Write(string.Join(";", values));
                    sw.Write('\n');
                }
                connection.Close();
            }


        }

        static void Statstous(MySqlConnection connection)
        {
            Console.Clear();
            string mois = "AND MONTH(c.date_creation)=";
            string annee = "2023";
            string reponse1 = "";
            Console.WriteLine("Mois ou annee 2023 (\"mois\" ou \"annee\") ?");
            reponse1 = Console.ReadLine();
            if (reponse1 == "mois")
            {
                Console.WriteLine("De quel mois ?");
                mois += Console.ReadLine();
            }
            else
                mois = " ";


            string path = "./Statistiques/Statistiques tous magasins" + mois + " " + annee + ".csv"; //chemin pour créer le dossier

            using (StreamWriter sw = new StreamWriter(path, true)) //Créer ou ouvrir le fichier stats3.csv en mode écriture
            {
                //MySqlCommand command = connection.CreateCommand();
                //command.CommandText = "SELECT cl.id,cl.nom,prenom,telephone,courriel,adresse_facturation,statut_fidélité,c.id as 'numéro de commande',m.nom, c.date_creation,c.adresse_livraison,c.message_accompagnant,c.date_livraison, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as 'Produits commandés' FROM produits p, commandes c, clients cl, Commandes_Produits cp, Magasins m WHERE c.id_client = cl.id AND cp.id_commande = c.id AND cp.id_produit = p.id AND c.id_magasin = m.id GROUP BY c.id order by statut_fidélité;";
                //MySqlDataReader reader;
                //reader = command.ExecuteReader();




                for (int i = 0; i < 17; i++)
                {
                    sw.Write(mois[mois.Length - 1] + " " + annee + " ");
                }
                sw.Write("\n" + "Sarah & Marie");
                for (int i = 0; i < 5; i++)
                {
                    sw.Write("Sarah & Marie");
                }
                sw.Write("\n");
                sw.Write("\n");



                //Première rangé
                List<string> CAmagasinstous = CAMagasintous(connection, mois);
                sw.Write("CA : ;" +CAmagasinstous[CAmagasinstous.Count()-1]+ ";;");//Attnetion
                Console.Clear();
                sw.Write("Bouquet le plus vendu : ;" + Meilleurbouquetdesmagasins(connection, "BOUQUET_STANDARD", "DESC", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("Fleur la plus vendu : ;" + Meilleurbouquetdesmagasins(connection, "FLEUR", "DESC", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("Accessoire le plus vendu : ;" + Meilleurbouquetdesmagasins(connection, "ACCESSOIRE", "DESC", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("\n");
                List<string> Nb = Nbcommandestous(connection, mois);
                sw.Write("Nombre de commandes : ;" + Nb[Nb.Count()-1]+ ";;");//Attention
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquetdesmagasins(connection, "BOUQUET_STANDARD", "DESC", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquetdesmagasins(connection, "FLEUR", "DESC", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquetdesmagasins(connection, "ACCESSOIRE", "DESC", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("\n ; ; ;");
                sw.Write("CA : ;" + Meilleurbouquetdesmagasins(connection, "BOUQUET_STANDARD", "DESC", mois, annee)[2] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + Meilleurbouquetdesmagasins(connection, "FLEUR", "DESC", mois, annee)[2] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + Meilleurbouquetdesmagasins(connection, "ACCESSOIRE", "DESC", mois, annee)[2] + ";;");
                Console.Clear();


                sw.Write("\n");
                sw.Write("\n");
                sw.Write("\n");
                sw.Write("\n");


                //Deuxième rangé
                List<string> donnee = Meilleurclienttous(connection, mois, annee);//Attention
                sw.Write("Meilleur client : ;" + donnee[0] + " " + donnee[1] + ";;");
                Console.Clear();
                sw.Write("Bouquet le moins vendu : ;" + Meilleurbouquetdesmagasins(connection, "BOUQUET_STANDARD", "", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("Fleur la moins vendu : ;" + Meilleurbouquetdesmagasins(connection, "FLEUR", "", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("Accessoire le moins vendu : ;" + Meilleurbouquetdesmagasins(connection, "ACCESSOIRE", "", mois, annee)[0] + ";;");
                Console.Clear();
                sw.Write("\n");
                sw.Write("Nombre de commandes : ;" + donnee[2] + ";;");
                sw.Write("quantite vendue : ;" + Meilleurbouquetdesmagasins(connection, "BOUQUET_STANDARD", "", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquetdesmagasins(connection, "FLEUR", "", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + Meilleurbouquetdesmagasins(connection, "ACCESSOIRE", "", mois, annee)[1] + ";;");
                Console.Clear();
                sw.Write("\n");
                sw.Write("CA engendre : ;" + donnee[3] + ";;");
                sw.Write("CA : ;" + Meilleurbouquetdesmagasins(connection, "BOUQUET_STANDARD", "", mois, annee)[2] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + Meilleurbouquetdesmagasins(connection, "FLEUR", "", mois, annee)[2] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + Meilleurbouquetdesmagasins(connection, "ACCESSOIRE", "", mois, annee)[2] + ";;");
                Console.Clear();


                sw.Write("\n");
                sw.Write("\n");
                sw.Write("\n");
                sw.Write("\n");


                //Troisième rangé
                List<string> donnee1 = PrixMoyentous(connection, mois);
                Console.Clear();
                List<string> donnee2 = Ventetous(connection, mois);
                Console.Clear();
                sw.Write("Prix Moyen Bouquets : ;" + donnee1[0] + ";;");
                sw.Write("Bouquets vendus ;" + ";;");
                sw.Write("Fleurs vendues ;" + ";;");
                sw.Write("Accessoires vendus ;" + ";;");
                sw.Write("\n");
                sw.Write("Prix Moyen Fleurs ;" + donnee1[1] + ";;");
                sw.Write("quantite vendue : ;" + donnee2[0] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + donnee2[2] + ";;");
                Console.Clear();
                sw.Write("quantite vendue : ;" + donnee2[4] + ";;");
                Console.Clear();
                sw.Write("\n");
                sw.Write("Prix Moyen Accessoires : ;" + donnee1[2] + ";;");
                sw.Write("CA : ;" + donnee2[1] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + donnee2[3] + ";;");
                Console.Clear();
                sw.Write("CA : ;" + donnee2[5] + ";;");
                Console.Clear();
            }


            string path1 = "./Statistiques/Clients Sarah & Marie.csv"; //chemin pour créer le dossier

            using (StreamWriter sw = new StreamWriter(path1, true)) //Créer ou ouvrir le fichier stats.csv en mode écriture
            {
                sw.Write("id;nom;prenom;telephone;courriel;adresse facturation;fidelite;id commande;magasin;date de commande;adresse livraison;message;date liraison;produits");
                sw.Write('\n');
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT cl.id,cl.nom,prenom,telephone,courriel,adresse_facturation,statut_fidélité,c.id as 'numéro de commande',m.nom, c.date_creation,c.adresse_livraison,c.message_accompagnant,c.date_livraison, GROUP_CONCAT(concat(cp.quantite, ' ', p.nom) SEPARATOR ', ') as 'Produits commandés' FROM produits p, commandes c, clients cl, Commandes_Produits cp, Magasins m WHERE c.id_client = cl.id AND cp.id_commande = c.id AND cp.id_produit = p.id AND c.id_magasin = m.id GROUP BY c.id order by statut_fidélité;";
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    sw.Write(string.Join(";", values));
                    sw.Write('\n');
                }
                connection.Close();

            }



            string path3 = "./Statistiques/Stock Sarah & Marie.csv"; //chemin pour créer le dossier

            using (StreamWriter sw = new StreamWriter(path3, true)) //Créer ou ouvrir le fichier stats.csv en mode écriture
            {
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "select p.nom,p.prix,p.categorie,im.quantite,m.nom from produits p, Inventaire_magasin im, Magasins m where im.id_magasin=m.id and im.id_produit=p.id order by m.id;";
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                sw.Write("Nom du bouquet;prix;categorie;quantite;magasin");
                sw.Write('\n');
                while (reader.Read())
                {
                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    sw.Write(string.Join(";", values));
                    sw.Write('\n');
                }
                connection.Close();
            }


            string path4 = "./Statistiques/Etatdescommandesactuel Sarah & Marie.csv"; //chemin pour créer le dossier

            using (StreamWriter sw = new StreamWriter(path4, true)) //Créer ou ouvrir le fichier stats.csv en mode écriture
            {
                connection.Open();
                Console.WriteLine("Etat actuel des commandes : ");
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT c.id,(SELECT sc.code_etat FROM Statuts_Commandes sc WHERE sc.id_commande = c.id ORDER BY sc.date_etat DESC LIMIT 1) as 'etat',(SELECT MAX(sc.date_etat) FROM Statuts_Commandes sc WHERE sc.id_commande = c.id) as 'date', m.nom FROM Commandes c, magasins m where c.id_magasin = m.id order by etat; ";
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                sw.Write("Numero de commande;état actuel;derniere maj;Magasin");
                sw.Write('\n');
                while (reader.Read())
                {
                    object[] values = new object[reader.FieldCount];
                    reader.GetValues(values);
                    sw.Write(string.Join(";", values));
                    sw.Write('\n');
                }
                connection.Close();
            }
        }
    }
}
