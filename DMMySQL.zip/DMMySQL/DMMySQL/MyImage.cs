﻿using System;
using System.IO;
using System.Threading;


namespace DMMySQL
{
    public class MyImage
    {
        //Constructeurs
        string type;
        int taille;
        int tailleOffset;
        int largeur;
        int hauteur;
        int nbbits;
        Pixel[,] data;
        byte[] lesautres;
        //Creation de MyImage à partir d'un fichier
        public MyImage(string myfile)
        {
            byte[] fichier = File.ReadAllBytes(myfile); // Lire les octets du fichier
            this.type += Convert.ToChar(fichier[0]);
            this.type += Convert.ToChar(fichier[1]); // Convertir les deux octets en tant que "type"

            // Extraire les octets de la taille, largeur, hauteur, taille offset etc
            byte[] tabtaille = { fichier[2], fichier[3], fichier[4], fichier[5] };
            byte[] tabtailleoffset = { fichier[10], fichier[11], fichier[12], fichier[13] };
            byte[] tablargeur = { fichier[18], fichier[19], fichier[20], fichier[21] };
            byte[] tabhauteur = { fichier[22], fichier[23], fichier[24], fichier[25] };
            byte[] tabnbbits = { fichier[28], fichier[29] };

            // Convertir les octets de taille, largeur, hauteur,taille offset etc
            this.taille = Convertir_Endian_To_Int(tabtaille);
            this.largeur = Convertir_Endian_To_Int(tablargeur);
            this.hauteur = Convertir_Endian_To_Int(tabhauteur);
            this.tailleOffset = Convertir_Endian_To_Int(tabtailleoffset);
            this.nbbits = Convertir_Endian_To_Int(tabnbbits);

            this.data = new Pixel[this.hauteur, this.largeur]; // Créer une matrice de Pixels avec les tailles précédentes
            int ind = this.tailleOffset;

            // Parcourir les données de pixels dans le fichier et remplir la matrice de pixels
            for (int x = 0; x < this.hauteur; x++)
            {
                for (int y = 0; y < this.largeur; y++)
                {
                    byte r = fichier[ind + 2]; // Extraire la valeur du composant R 
                    byte g = fichier[ind + 1]; // Extraire la valeur du composant G
                    byte b = fichier[ind + 0]; // Extraire la valeur du composant B
                    ind += 3;
                    this.data[x, y] = new Pixel(r, g, b);
                }
            }

            this.lesautres = new byte[this.tailleOffset - 30]; // Créer un tableau d'octets des autres bytes
            for (int i = 30; i < this.tailleOffset; i++) // Parcourir les autres octets jusqu'à la fin du header
            {
                this.lesautres[i - 30] = fichier[i];
            }
        }
        //Création d'une instance MyImage à partir d'une largeur d'une hauteur et d'une couleur
        public MyImage(int largeur, int hauteur, Pixel a)
        {
            Byte[] tab = { 66, 77, 0, 0, 0, 0, 0, 0, 0, 0, 54, 0, 0, 0, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };//Header générique
            Byte[] image = new byte[largeur * hauteur * 3 + 54];
            for (int i = 0; i < 54; i++)
            {
                image[i] = tab[i];
            }
            //Conversion, voir précédemment, même principe
            int taille = largeur * hauteur * 3 + 54;
            byte[] tableaulargeur = this.Convertir_Int_To_Endian(largeur);
            byte[] tableauhauteur = this.Convertir_Int_To_Endian(hauteur);
            byte[] tableautaille = this.Convertir_Int_To_Endian(taille);
            image[2] = tableautaille[0];
            image[3] = tableautaille[1];
            image[4] = tableautaille[2];
            image[5] = tableautaille[3];
            image[18] = tableaulargeur[0];
            image[19] = tableaulargeur[1];
            image[20] = tableaulargeur[2];
            image[21] = tableaulargeur[3];
            image[22] = tableauhauteur[0];
            image[23] = tableauhauteur[1];
            image[24] = tableauhauteur[2];
            image[25] = tableauhauteur[3];
            this.largeur = largeur;
            this.hauteur = hauteur;
            this.type = "BM";
            this.tailleOffset = 54;
            this.taille = largeur * hauteur * 3 + 54;
            this.nbbits = 24;
            this.lesautres = new byte[this.tailleOffset - 30];
            this.data = new Pixel[this.hauteur, this.largeur];
            for (int i = 30; i < this.tailleOffset; i++)
            {
                this.lesautres[i - 30] = 0;
            }
            //Matrice de pixels remplie
            for (int i = 0; i < this.hauteur; i++)
            {

                for (int j = 0; j < this.largeur; j++)
                {
                    this.data[i, j] = a;
                }
            }
        }

        public int Largeur
        {
            get { return this.largeur; }
            set { this.largeur = value; }
        }
        public Pixel[,] Data
        {
            get { return this.data; }
            set { this.data = value; }
        }
        public int Hauteur
        {
            get { return this.hauteur; }
            set { this.hauteur = value; }
        }
        public string Type
        {
            get { return this.type; }
            set { this.type = value; }
        }
        public int Taille
        {
            get { return this.taille; }
            set { this.taille = value; }
        }
        public int TailleOffset
        {
            get { return this.tailleOffset; }
            set { this.tailleOffset = value; }
        }
        public Byte[] Lesautres
        {
            get { return this.lesautres; }
            set { this.lesautres = value; }
        }
        public int Nbbits
        {
            get { return this.nbbits; }
            set { this.nbbits = value; }
        }

        //Sauvegarde de la variable MyImage dans un fichier bmp
        public void From_Image_To_File(string file)
        {
            //Réécriture dans un tableau de bytes et conversion
            byte[] imageBytes = new byte[this.taille];
            imageBytes[0] = Convert.ToByte(this.type[0]);
            imageBytes[1] = Convert.ToByte(this.type[1]);
            byte[] tableautaille = this.Convertir_Int_To_Endian(this.Taille);
            byte[] tableautailleoffset = this.Convertir_Int_To_Endian(this.TailleOffset);
            byte[] tableaulargeur = this.Convertir_Int_To_Endian(this.largeur);
            byte[] tableauhauteur = this.Convertir_Int_To_Endian(this.hauteur);
            byte[] tableaunbcouleurs = this.Convertir_Int_To_Endian(this.nbbits);
            imageBytes[2] = tableautaille[0];
            imageBytes[3] = tableautaille[1];
            imageBytes[4] = tableautaille[2];
            imageBytes[5] = tableautaille[3];
            imageBytes[10] = tableautailleoffset[0];
            imageBytes[11] = tableautailleoffset[1];
            imageBytes[12] = tableautailleoffset[2];
            imageBytes[13] = tableautailleoffset[3];
            imageBytes[14] = 40;
            imageBytes[18] = tableaulargeur[0];
            imageBytes[19] = tableaulargeur[1];
            imageBytes[20] = tableaulargeur[2];
            imageBytes[21] = tableaulargeur[3];
            imageBytes[22] = tableauhauteur[0];
            imageBytes[23] = tableauhauteur[1];
            imageBytes[24] = tableauhauteur[2];
            imageBytes[25] = tableauhauteur[3];
            imageBytes[26] = 1;
            imageBytes[28] = tableaunbcouleurs[0];
            imageBytes[29] = tableaunbcouleurs[1];
            for (int i = 30; i < this.tailleOffset; i++)
            {
                imageBytes[i] = lesautres[i - 30];
            }
            int k = this.tailleOffset;
            //parcourir les données de la matrice de pixels
            for (int j = 0; j < this.data.GetLength(0); j++)
            {
                for (int i = 0; i < this.data.GetLength(1); i++)
                {
                    imageBytes[k] = this.data[j, i].B;
                    k++;
                    imageBytes[k] = this.data[j, i].G;
                    k++;
                    imageBytes[k] = this.data[j, i].R;
                    k++;
                }
            }
            //enregistrement
            File.WriteAllBytes(file, imageBytes);
        }

        //Convertir endian en int
        public int Convertir_Endian_To_Int(byte[] tab)
        {
            int final = 0;
            for (int i = 0; i < tab.Length; i++)
            {
                final += tab[i] * (int)(Math.Pow(256, i));
            }
            return final;
        }

        //Convertir int en endian
        public byte[] Convertir_Int_To_Endian(int val)
        {
            byte[] tab = new byte[4];
            for (int i = tab.Length - 1; i >= 0; i--)
            {
                tab[i] = (byte)(val / ((int)(Math.Pow(256, i))));
                val = val % ((int)(Math.Pow(256, i)));
            }
            return tab;
        }

        //Convertir endian en byte
        public byte Convertir_EndianB_To_Byte(int[] tab)
        {
            int final = 0;
            for (int i = 0; i < tab.Length; i++)
            {
                final += tab[i] * (int)(Math.Pow(2, i));
            }
            return Convert.ToByte(final);
        }

        //Convertir byte en endian
        public int[] Convertir_Byte_To_EndianB(byte val)
        {
            int[] tab = new int[8];
            int val2 = Convert.ToInt32(val);
            for (int i = tab.Length - 1; i >= 0; i--)
            {
                tab[i] = (byte)(val2 / ((int)(Math.Pow(2, i))));
                val2 = val2 % ((int)(Math.Pow(2, i)));
            }
            return tab;
        }
        // Réduire la taille de l'image
        public void Reduire(int coef)
        {
            int newWidth = this.largeur / coef; // Nouvelle taille
            int newHeight = this.hauteur / coef;
            Pixel[,] mat = new Pixel[newHeight, newWidth]; // nouvelle matrice

            for (int i = 0; i < newHeight; i++) // Parcourir données
            {
                for (int j = 0; j < newWidth; j++)
                {
                    int sommeR = 0; // Variable pour stocker la somme des composantes rouges
                    int sommeG = 0; // Variable pour stocker la somme des composantes vertes
                    int sommeB = 0; // Variable pour stocker la somme des composantes bleues

                    for (int k = i * coef; k < (i + 1) * coef; k++) // la zone réduite
                    {
                        for (int l = j * coef; l < (j + 1) * coef; l++)
                        {
                            sommeR += data[k, l].R;
                            sommeG += data[k, l].G;
                            sommeB += data[k, l].B;
                        }
                    }

                    // Calculer les nouvelles composantes RGB
                    mat[i, j] = new Pixel((byte)(sommeR / (coef * coef)), (byte)(sommeG / (coef * coef)), (byte)(sommeB / (coef * coef))); //Moyenne
                }
            }

            // Mettre à jour la largeur, hauteur, matrice de pixels et taille de l'image réduite
            this.largeur = newWidth;
            this.hauteur = newHeight;
            this.data = mat;
            this.taille = this.largeur * this.hauteur * 3 + this.tailleOffset;
        }
        //Afficher l'image dans la console
        public void Afficher()
        {
            // Parcourir les pixels
            for (int i = this.data.GetLength(0) - 1; i >= 0; i--)
            {
                for (int j = 0; j < this.data.GetLength(1); j++)
                {
                    // Récupérer la couleur la plus proche du pixel à l'emplacement (i, j)
                    Pixel closestColor = this.data[i, j].Lepixelleplusproche();

                    // Définir la couleur de texte de la console comme étant la couleur la plus proche du pixel
                    Console.ForegroundColor = Pixel.Bonnecouleur(closestColor);

                    // Afficher "**" pour représenter le pixel à l'emplacement (i, j)
                    Console.Write("**");
                }
                Console.WriteLine();
            }
        }


    }
}
